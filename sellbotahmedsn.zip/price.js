
module.exports = async (client) => {
  let array = [
    
    {
      name: "price-with-tax",
      description: "select the price for each bot",
      options: [

            {
              name: "tax",
              description: ".",
              type: "INTEGER" ,
              required : true
            } ,
            {
              name: "close-open",
              description: ".",
              type: "INTEGER" ,
              required : true
            },
            {
              name: "autoline",
              description: ".",
              type: "INTEGER" ,
              required : true
            },
            {
                name: "broadcast",
                description: ".",
                type: "INTEGER" ,
                required : true
              },
              {
                name: "suggestion",
                description: ".",
                type: "INTEGER" ,
                required : true
              },
              {
                name: "moderation",
                description: ".",
                type: "INTEGER" ,
                required : true
              },
              {
                name: "ticket",
                description: ".",
                type: "INTEGER" ,
                required : true
              },
              {
                name: "giveaway",
                description: ".",
                type: "INTEGER" ,
                required : true
              },
              {
                name: "say",
                description: ".",
                type:"INTEGER" ,
                required : true
              },
              {
                name: "come",
                description: ".",
                type: "INTEGER" ,
                required : true
              },


          ]
        },
        {
            name: "price-without-tax",
            description: "select the price for each bot",
            options: [
      
                  {
                    name: "tax",
                    description: ".",
                    type: "INTEGER" ,
                    required : true
                  } ,
                  {
                    name: "close-open",
                    description: ".",
                    type: "INTEGER" ,
                    required : true
                  },
                  {
                    name: "autoline",
                    description: ".",
                    type: "INTEGER" ,
                    required : true
                  },
                  {
                      name: "broadcast",
                      description: ".",
                      type: "INTEGER" ,
                      required : true
                    },
                    {
                      name: "suggestion",
                      description: ".",
                      type: "INTEGER" ,
                      required : true
                    },
                    {
                      name: "moderation",
                      description: ".",
                      type: "INTEGER" ,
                      required : true
                    },
                    {
                      name: "ticket",
                      description: ".",
                      type: "INTEGER" ,
                      required : true
                    },
                    {
                      name: "giveaway",
                      description: ".",
                      type: "INTEGER" ,
                      required : true
                    },
                    {
                      name: "say",
                      description: ".",
                      type:"INTEGER" ,
                      required : true
                    },
                    {
                      name: "come",
                      description: ".",
                      type: "INTEGER" ,
                      required : true
                    },

      
      
                ]
              },
              {
                name: "log-channel",
                description: "select the channel for logging allthing",
                options: [
          
                      {
                        name: "channel",
                        description: ".",
                        type: "CHANNEL" ,
                        required : true
                      } ,

          
          
                    ]
                  },
                  {
                    name: "log-channel-make",
                    description: "select the channel for logging when someone bought a bot",
                    options: [
              
                          {
                            name: "channel",
                            description: "put the id of channel",
                            type: "STRING" ,
                            required : true
                          } ,
    
              
              
                        ]
                      },
                      {
                        name: "help",
                        description: "help menu",
                   
                          },

                          {
                            name: "change-prefix",
                            description: "Change prefix for maker bot",
                            options: [
                      
                                  {
                                    name: "prefix",
                                    description: "your maker bot prefix",
                                    type: "STRING" ,
                                    required : true
                                  } ,
            
                      
                      
                                ]
                              },
                              {
                                name: "owner",
                                description: "select the channel for logging allthing",
                                options: [
                          
                                      {
                                        name: "owner-id",
                                        description: "put your account that will recieve the credits",
                                        type: "STRING" ,
                                        required : true
                                      } ,
                
                          
                          
                                    ]
                                  },

                                  {
                                    name: "change-embed",
                                    description: "change the image in the embed",
                                    options: [
                              
                                          {
                                            name: "image",
                                            description: "put image Url",
                                            type: "STRING" ,
                                            required : true
                                          } ,
                    
                              
                              
                                        ]
                                      },

                  
]
  await client.application.commands.set(array);
}
