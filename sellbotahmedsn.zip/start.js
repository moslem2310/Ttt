const createMainBot = require('./index.js');
const createKickBot = require('./kickBot.js');
const createBanBot = require('./banBot.js');
const mongoose = require('mongoose');
const token = require('./models/tokenn.js');

const Discord = require("discord.js");

const createtax = require ('./tax.js')
const client = new Discord.Client({
  intents: ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS"]
});


async function start() {
  
    await mongoose.connect('mongodb+srv://Ahmed:12345@ahmed.f1uxuex.mongodb.net/data');
    console.log('Connected to MongoDB');

    const allTokens = await token.find({});
    allTokens.forEach((guildToken) => {
      guildToken.botTokens.forEach(async (botToken) => {
        let activatedBot = createKickBot(botToken);
        await activatedBot.connect();
      });
    });

 
  
}

start();
    

  
