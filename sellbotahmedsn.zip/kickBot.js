const Discord = require('discord.js')




const token = require('./models/tokens.js');
const linee = require ('./models/line.js');
const config = require("./config.json");
const prefix = config.prefix;

const fs = require('fs');
const {
  MessageAttachment
} = require('discord.js');
const {
  MessageEmbed,
  permissionOverwrites,
  MessageSelectMenu,
  TextInputComponent,
  ChannelType,
  MessageButton,
  MessageActionRow,
  Modal,
  Permissions
} = require("discord.js");
const oc = require('./models/oc.js')
const {
  Client,
  Intents
} = require('discord.js');
const shortid = require('shortid');
const myId = shortid.generate();
const counter= require('./models/counter.js')
const moment = require('moment')
const client = new Discord.Client({
  intents: ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS"]
});



// Require the ban bot module and pass the Client class
// const banBot = require('./banBot')(Client, 'MTEwMzA2ODM2NDg3MzY2NjU4MQ.GG9bYB.j63lRXQrKYRuiJq4ZmErANr4tezzKb5L4GrZlE');

// client.on('ready',async () => {
//   console.log('Bot is online!');

 
// });
const mongoose = require("mongoose");
const db = require("./models/shop");
const user_db = require("./models/user");
const toto = require("./models/steck");
const tokens = require("./models/tokens");

const sayy = require("./say");
const price = require("./price");


function createKickBot(token) {
    const client = new Client({ intents: ['GUILDS', 'GUILD_MESSAGES'] });
  
    client.on('ready', () => {
      console.log(`Kick bot is online with token ${token}`);
    });
        mongoose.connect("mongodb+srv://Ahmed:12345@ahmed.f1uxuex.mongodb.net/data"); //// https://youtu.be/gtykpkOYy94
client.on("ready", async () => {
    console.log(client.user.tag);
    await price(client)
  });
      
const emo = require ('./models/embed.js')

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return
  if (interaction.commandName === 'change-embed') {

    const image = interaction.options.getString('image')

    await emo.findOneAndUpdate(
      {id : interaction.guild.id} ,
      {image : image},
      {upsert : true}
    )
    
    
    const gaf = await emo.findOne({id : interaction.guild.id})

    if (!image.startsWith('https://')) return interaction.reply({content : `**invalid image Please put an url correct of image**`})

if (image) {
  await interaction.deferReply({fetchReply : true , ephemeral : true})
  await interaction.editReply({embeds : [new MessageEmbed().setDescription(`**Done saved your image in database in your maker bot ${gaf.image}**`)] })
}

  }
})

//// put your bot code here
//// help for maker bot 
//// help for maker bot 
const prefixw = require('./models/prefix.js')

//// put your bot code here


//// put your bot code here

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return
  if (interaction.commandName === 'help') {
    const ya = await prefixw.findOne({id : interaction.guild.id})
    const meto = new MessageSelectMenu()
    .setCustomId('meto')
    .setPlaceholder('nothing selected yet')
    .addOptions(
      {
        label : `${ya.prefix}maker`,
        description : `Note : this is the only command in maker bot in prefix` ,
        value : `**This command for showing you a menu of maker bot for buying bots ..**`
      } ,
      {
        label : `change-prefix`,
        description : `press to know` ,
        value : `**This command for set your preferable prefix ..**`
      } ,
      {
        label : `log-channel`,
        description : `press to know` ,
        value : `**This command for set log channel that the bot will send all buying to it**`
      } ,

      {
        label : `price-with-tax`,
        description : `press to know` ,
        value : `**This command for setting a price for al bots with tax **`
      } ,
      {
        label : `price-without-tax`,
        description : `press to know` ,
        value : `**This command for setting a price for al bots without tax **`
      } ,
    )
const jas = new MessageActionRow()
.addComponents(meto)
    await interaction.deferReply({fetchReply : true})
    await interaction.editReply({embeds : [new MessageEmbed().setDescription(`**This is a help menu for You 🙎**`).setImage('https://media.discordapp.net/attachments/1105949579851071579/1126764562255990824/-.jpg?width=1025&height=342')] , components : [jas]})

  }
})

///// prefix 

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return
  if (interaction.commandName === 'change-prefix') {

   if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
      return interaction.reply({
        content: 'You do not have permission to use this command!',
        ephemeral: true,
      });
    }
    const prefix = interaction.options.getString('prefix')
 await prefixw.findOneAndUpdate(
  {id : interaction.guild.id} ,
  {prefix : prefix},
  {upsert : true}
)


const gaf = await prefixw.findOne({id : interaction.guild.id})
await interaction.deferReply({fetchReply : true , ephemeral : true})
await interaction.editReply({embeds : [new MessageEmbed().setDescription(`**Done Saved your maker bot prefix in database and your prefix is ${gaf.prefix}**`)]}) 
  }
})
client.on('interactionCreate', async interaction => {
  if (!interaction.isSelectMenu()) return
  if (interaction.customId === 'meto') {
    let selectedOption = interaction.values[0];
    await interaction.deferReply({fetchReply : true , ephemeral : true})
    await interaction.editReply({embeds : [new MessageEmbed().setDescription(`**${selectedOption} 🙎**`)]})

  }
})
/////////////////////////////////////// select the prices Ahmed Sn
const proce = require('./models/price.js') // with tax
const prece = require('./models/prece.js') /// without 
client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return
  if (interaction.commandName === 'price-with-tax') {
         if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
      return interaction.reply({
        content: 'You do not have permission to use this command!',
        ephemeral: true,
      });
    }

    const tax = interaction.options.getInteger('tax')
    const open = interaction.options.getInteger('close-open')
    const autoline = interaction.options.getInteger('autoline')
    const broadcast = interaction.options.getInteger('broadcast')
    const suggestion = interaction.options.getInteger('suggestion')
    const moderation = interaction.options.getInteger('moderation')
    const ticket = interaction.options.getInteger('ticket')
    const giveaway = interaction.options.getInteger('giveaway')
    const say = interaction.options.getInteger('say')
    const come = interaction.options.getInteger('come')

await proce.findOneAndUpdate(
  {id : interaction.guild.id} ,
  {
    Price : 
    {
      tax : tax ,
      open : open , 
      autoline : autoline , 
      broadcast : broadcast , 
      suggestion : suggestion ,
      moderation : moderation , 
      ticket : ticket , 
      giveaway : giveaway , 
      say : say ,
      come : come
    }
  } ,
  {upsert : true}
) 

await interaction.reply ({content : `Done saved all prices with tax in database`})
    
  }else {
    if (interaction.commandName === 'price-without-tax') {
           if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
      return interaction.reply({
        content: 'You do not have permission to use this command!',
        ephemeral: true,
      });
    }
      const tax = interaction.options.getInteger('tax')
      const open = interaction.options.getInteger('close-open')
      const autoline = interaction.options.getInteger('autoline')
      const broadcast = interaction.options.getInteger('broadcast')
      const suggestion = interaction.options.getInteger('suggestion')
      const moderation = interaction.options.getInteger('moderation')
      const ticket = interaction.options.getInteger('ticket')
      const giveaway = interaction.options.getInteger('giveaway')
      const say = interaction.options.getInteger('say')
      const come = interaction.options.getInteger('come')
 
  

      await prece.findOneAndUpdate(
        {id : interaction.guild.id} ,
        {
          Price : 
          {
            tax : tax ,
            open : open , 
            autoline : autoline , 
            broadcast : broadcast , 
            suggestion : suggestion ,
            moderation : moderation , 
            ticket : ticket , 
            giveaway : giveaway , 
            say : say ,
            come : come
          }
        } ,
        {upsert : true}
      ) 
      

  await interaction.reply ({content : `Done saved all prices without tax in database`})

      }


  }

})
///// owner
const Owner = require('./models/owner.js')

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return
  if (interaction.commandName === 'owner') {
         if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
      return interaction.reply({
        content: 'You do not have permission to use this command!',
        ephemeral: true,
      });
    }
    const owner = interaction.options.getString('owner-id')
    
    await Owner.findOneAndUpdate(
      { id: interaction.guild.id },
      { owner: owner },
      { upsert: true }
    )
    
    await interaction.reply({ content: 'Owner ID saved in database' })
  }
})
////// for log 

const logg = require ('./models/logg.js')
client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return
  if (interaction.commandName === 'log-channel') {
         if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
      return interaction.reply({
        content: 'You do not have permission to use this command!',
        ephemeral: true,
      });
    }

    const log = interaction.options.getChannel('channel')


    await logg.findOneAndUpdate(
      {id : interaction.guild.id} ,
      {
        channel : log
      } ,
      {upsert : true}
    ) 
    const gac = await logg.findOne({id : interaction.guild.id})
await interaction.reply({content : `Done saved the log channel ${gac.channel} for allthing for buying in database` , ephemeral : true})

  }
})


const loggg = require ('./models/loggg.js')
client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return
  if (interaction.commandName === 'log-channel-make') {
         if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
      return interaction.reply({
        content: 'You do not have permission to use this command!',
        ephemeral: true,
      });
    }

    const log = interaction.options.getString('channel')


    await loggg.findOneAndUpdate(
      {id : interaction.guild.id} ,
      {
        channel : log
      } ,
      {upsert : true}
    ) 
    const gac = await loggg.findOne({id : interaction.guild.id})
await interaction.reply({content : `Done saved the log channel ${gac.channel} for allthing that someone make a bot in database` , ephemeral : true})

  }
})


// const loggg = require ('./models/loggg.js')
// client.on('interactionCreate', async interaction => {
//   if (!interaction.isCommand()) return
//   if (interaction.commandName === 'log-channel-make') {

//     const log = interaction.options.getChannel('channel')

// loggg.findOne({id : interaction.guild.id} , async (data) => {
//   if (!data) {
//     loggg.create (
//       {
//         id : interaction.guild.id,
//         channel : log
//       }
//     )
//   }
// })
// await interaction.reply({content : `Done saved the log channel for altering that someone bought a bot ` , ephemeral : true})

//   }
// })

let optionss = [{
    label: 'Tax bot',
    description: 'لشراء بوت ضريبة',
    value: 'tax',
    selected: false
  },
  {
    label: 'Close and open rooms bot',
    description: 'بوت قفل وفتح رومات البيع',
    value: 'oc',
    selected: false
  },
  {
    label: 'Autoline bot',
    description: 'بوت خط تلقائى',
    value: 'line',
    selected: false
  },
  {
    label: 'Broadcast bot',
    description: 'بوت برودكاست',
    value: 'broad',
    selected: false
  },
    {
    label: 'Suggestion bot',
    description: 'بوت اقتراحات',
    value: 'sug',
    selected: false
  },
  {
    label: 'Moderation bot',
    description: 'بوت اوامر ادارية',
    value: 'mod',
    selected: false
  },
  {
    label: 'Ticket bot',
    description: 'بوت تيكيت',
    value: 'giv',
    selected: false
  },
  {
    label: 'Giveaway bot ',
    description: 'بوت جيفاواى',
    value: 'gav',
    selected: false
  },
  {
    label: 'Say with or without embed bot ',
    description: ' بوت ساى بامبيدأو بدون امبيد',
    value: 'say',
    selected: false
  },
  {
    label: 'Come bot',
    description: 'بوت نداء',
    value: 'come',
    selected: false
  },
  {
    label: 'Reset',
    description: 'Reset the selected option',
    value: 'reset',
    selected: false
  }


];

// Shorten the value of each option to 100 characters or less
optionss.forEach(option => {
  option.value = option.value.slice(0, 100);
});




//

const createtax = require('./tax.js');
const MakerModel = require('./models./maker.js'); // Import the Maker model

MakerModel.find({}, 'token') // Find all documents and only select the 'token' field
  .then(makers => {
    const botTokens = makers.map(maker => maker.token); // Extract the 'token' values
    console.log('Found bot tokens:', botTokens);
    
    // Create and log in your new bots using the botTokens array
    botTokens.forEach(botToken => {
      const newBot = createtax(botToken);
    
      // Add event listeners and commands for the new bot as needed

      newBot.login(botToken);
    });
  })
  .catch(error => {
    console.log('Error fetching maker documents:', error);
  });
client.on('messageCreate', async message => {
  const tar = await prefixw.findOne({id : message.guild.id})
const sga = await emo.findOne({id : message.guild.id})
  const prefix = tar.prefix
  if (message.content.startsWith(prefix +'maker')) {
    const ment = new MessageSelectMenu()
      .setCustomId('met')
      .setPlaceholder('nothing selected')
      .setMaxValues(1)
      .setMinValues(1)
      .addOptions(optionss)
const hha = await prece.findOne({id : message.guild.id})
    const row = new MessageActionRow()
      .addComponents(ment)
    message.channel.send({
      embeds: [new MessageEmbed().setDescription(`**تاكد ان توكن بوتك صحيح قبل اضافته الى البوت
لا تمنشن احد في التكت الا في حدوث خطا اثناء عملية الشراء
يرجى عدم تغيير توكن الخاص ببوتك بعد اكتمال عمليه الشراء
تاكد انك مفعل اخر ثلاث خيرات بلبوت
ملاحظة : لا نقوم بتغيير توكن البوت من قديم الى جديد\n

Tax bot : بوت ضريبة | price : ${hha.Price.tax}

close and open rooms: بوت فتح و غلق رومات البيع | price : ${hha.Price.open}

AutoLine Bot :  بوت خط تلقائى | price : ${hha.Price.autoline}

Ticket Bot : بوت تيكيت | price : ${hha.Price.ticket}

Come bot : بوت نداء | price : ${hha.Price.come}

Broadcast Bot : بوت برودكاست | price : ${hha.Price.broadcast}

Say Bot : بوت ساى بامبيد وبدون امبيد | price : ${hha.Price.say}

Giveaway Bot : بوت جيفاواى بوحدة تخزيين مونجو | price : ${hha.Price.giveaway}

Moderation Bot : بوت ادارة كاملة | price : ${hha.Price.moderation}

Suggestion Bot : بوت اقتراحات | price : ${hha.Price.suggestion}


**`).setImage(`${sga.image}`).setTimestamp()],
      components: [row]
    })

   
    
  }
})

 



client.on('interactionCreate', async interaction => {
  if (!interaction.isSelectMenu()) return
  if (interaction.customId === 'met') {
    let selectedOption = interaction.values[0];
     let Counter = 0;
      let map = new Map()
      counter.findOne({id : interaction.guild.id} , async (data) => {
  if (!data) {
    counter.create(
      {
        count : Counter
      }
    )
  }
})
      
      Counter++
                                    let qq = await  counter.findOneAndUpdate(
                    {
                        id : interaction.guild.id ,
                        
                       
                        
                     

                    }
                )
qq.count += Counter;
                
                qq.save()

    if (selectedOption === 'tax') {
      await interaction.guild.channels.create(`ticket-${qq.count}`, {
        type: 'GUILD_TEXT',
        permissionOverwrites: [{
            id: interaction.guild.id,
            deny: [Permissions.FLAGS.VIEW_CHANNEL],
          },
          {
            id: interaction.user.id,
            allow: [Permissions.FLAGS.VIEW_CHANNEL],
          },

        ],
        // parent: `1110577124848447619` ,
      }).then(async channela => {
        map.set(Counter++)
        // setTimeout(async () => {

        //   await channela.delete()

        // }, 90000);
        const close = new MessageButton()
        .setCustomId('close')
        .setLabel('close')
        .setStyle('SUCCESS')

        const but = new MessageButton()
          .setCustomId('lol')
          .setLabel('continue')
          .setStyle('DANGER')

        const uu = new MessageActionRow()
          .addComponents(but , close)

          
        channela.send({
          content: `<@${interaction.user.id}>`,
          embeds: [new MessageEmbed().setDescription(`**لاستكمال عمليه الشراء قم بضغط علي زر
        "Continue" \n botType : tax bot**`)],
          components: [uu]
        })



        await interaction.deferReply({
          fetchReply: true,
          ephemeral: true
        })
        await interaction.editReply({
          content: `** Done ticket created ${channela} ✅**`
        })

      })

    }

    ///broad
    if (selectedOption === 'broad') {
      await interaction.guild.channels.create(`ticket-${qq.count}`, {
        type: 'GUILD_TEXT',
        permissionOverwrites: [{
            id: interaction.guild.id,
            deny: [Permissions.FLAGS.VIEW_CHANNEL],
          },
          {
            id: interaction.user.id,
            allow: [Permissions.FLAGS.VIEW_CHANNEL],
          },

        ],
        // parent: `1110577124848447619` ,
      }).then(async channelad => {
        map.set(Counter++)
        // setTimeout(async () => {

        //   await channela.delete()

        // }, 90000);
        const close = new MessageButton()
        .setCustomId('close')
        .setLabel('close')
        .setStyle('SUCCESS')

        const butd = new MessageButton()
          .setCustomId('lold')
          .setLabel('continue')
          .setStyle('DANGER')

        const uud = new MessageActionRow()
          .addComponents(butd , close)

          
        channelad.send({
          content: `<@${interaction.user.id}>`,
          embeds: [new MessageEmbed().setDescription(`**لاستكمال عمليه الشراء قم بضغط علي زر
        "Continue" \n botType : Broadcast bot**`)],
          components: [uud]
        })



        await interaction.deferReply({
          fetchReply: true,
          ephemeral: true
        })
        await interaction.editReply({
          content: `** Done ticket created ${channelad} ✅**`
        })

      })

    }
  
 
    
    if (selectedOption === 'reset') {
      selectedOption = null; // clear the selected option
    
      // reset the options array by setting the `selected` property of all options to `false`
      optionss.forEach(option => {
        option.selected = false;
      });
    
      await interaction.reply({content : `**Selection reset. Please choose an option from the menu.**` , ephemeral : true});
    } else {
      // clear the `selected` property of all options except the selected option
      optionss.forEach(option => {
        if (option.value === selectedOption) {
          option.selected = true;
        } else {
          option.selected = false;
        }
      });
    
      // code for handling other options
    }
    //// say
    if (selectedOption === 'say') {
      await interaction.guild.channels.create(`ticket-${qq.count}`, {
        type: 'GUILD_TEXT',
        permissionOverwrites: [{
            id: interaction.guild.id,
            deny: [Permissions.FLAGS.VIEW_CHANNEL],
          },
          {
            id: interaction.user.id,
            allow: [Permissions.FLAGS.VIEW_CHANNEL],
          },

        ],
        // parent: `1110577124848447619` ,
      }).then(async channelaq => {
        map.set(Counter++)
        // setTimeout(async () => {

        //   await channela.delete()

        // }, 90000);
        const close = new MessageButton()
        .setCustomId('close')
        .setLabel('close')
        .setStyle('SUCCESS')

        const butq = new MessageButton()
          .setCustomId('lolq')
          .setLabel('continue')
          .setStyle('DANGER')

        const uuq = new MessageActionRow()
          .addComponents(butq , close)

    
        channelaq.send({
          content: `<@${interaction.user.id}>`,
          embeds: [new MessageEmbed().setDescription(`**لاستكمال عمليه الشراء قم بضغط علي زر
        "Continue" \n botType : say bot**`)],
          components: [uuq]
        })



        await interaction.deferReply({
          fetchReply: true,
          ephemeral: true
        })
        await interaction.editReply({
          content: `** Done ticket created ${channelaq} ✅**`
        })

      })

    }

    /// come
    if (selectedOption === 'come') {
      await interaction.guild.channels.create(`ticket-${qq.count}`, {
        type: 'GUILD_TEXT',
        permissionOverwrites: [{
            id: interaction.guild.id,
            deny: [Permissions.FLAGS.VIEW_CHANNEL],
          },
          {
            id: interaction.user.id,
            allow: [Permissions.FLAGS.VIEW_CHANNEL],
          },

        ],
        // parent: `1110577124848447619` ,
      }).then(async channelae => {
        map.set(Counter++)
        // setTimeout(async () => {

        //   await channela.delete()

        // }, 90000);
        const close = new MessageButton()
        .setCustomId('close')
        .setLabel('close')
        .setStyle('SUCCESS')

        const bute = new MessageButton()
          .setCustomId('lole')
          .setLabel('continue')
          .setStyle('DANGER')

        const uue = new MessageActionRow()
          .addComponents(bute , close)

          
        channelae.send({
          content: `<@${interaction.user.id}>`,
          embeds: [new MessageEmbed().setDescription(`**لاستكمال عمليه الشراء قم بضغط علي زر
        "Continue" \n botType : come bot**`)],
          components: [uue]
        })



        await interaction.deferReply({
          fetchReply: true,
          ephemeral: true
        })
        await interaction.editReply({
          content: `** Done ticket created ${channelae} ✅**`
        })

      })

    }

    if (selectedOption === 'oc') {

      await interaction.guild.channels.create(`ticket-${qq.count}`, {
        type: 'GUILD_TEXT',
        permissionOverwrites: [{
            id: interaction.guild.id,
            deny: [Permissions.FLAGS.VIEW_CHANNEL],
          },
          {
            id: interaction.user.id,
            allow: [Permissions.FLAGS.VIEW_CHANNEL],
          },

        ],
        // parent: `1110577124848447619` ,
      }).then(async channelaa => {
        // setTimeout(async () => {

        //   await channela.delete()

        // }, 90000);
        const closee = new MessageButton()
        .setCustomId('close')
        .setLabel('close')
        .setStyle('SUCCESS')
        const butt = new MessageButton()
          .setCustomId('loll')
          .setLabel('continue')
          .setStyle('DANGER')

        const uuu = new MessageActionRow()
          .addComponents(butt )

          const kao = new MessageActionRow()
          .addComponents(closee)
        channelaa.send({
          content: `<@${interaction.user.id}>`,
          embeds: [new MessageEmbed().setDescription(`**لاستكمال عمليه الشراء قم بضغط علي زر
        "Continue" \n botType : open and close bot**`)],
          components: [uuu , kao]
        })



        await interaction.deferReply({
          fetchReply: true,
          ephemeral: true
        })
        await interaction.editReply({
          content: `** Done ticket created ${channelaa} ✅**`
        })
      })

    }
    // if (selectedOption === 'line') {
    //   await interaction.guild.channels.create(`ticket-${qq.count}`, {
    //     type: 'GUILD_TEXT',
    //     permissionOverwrites: [{
    //         id: interaction.guild.id,
    //         deny: [Permissions.FLAGS.VIEW_CHANNEL],
    //       },
    //       {
    //         id: interaction.user.id,
    //         allow: [Permissions.FLAGS.VIEW_CHANNEL],
    //       },

    //     ],
    //     // parent: `1110577124848447619` ,
    //   }).then(async channelaaa => {
    //     // setTimeout(async () => {

    //     //   await channela.delete()

    //     // }, 90000);
    //     const closeee = new MessageButton()
    //     .setCustomId('close')
    //     .setLabel('close')
    //     .setStyle('SUCCESS')
    //     const buttt = new MessageButton()
    //       .setCustomId('lolll')
    //       .setLabel('continue')
    //       .setStyle('DANGER')

    //     const uuuu = new MessageActionRow()
    //       .addComponents(buttt )
    //       const kao = new MessageActionRow()
    //       .addComponents(closeee)
    //     channelaaa.send({
    //       content: `<@${interaction.user.id}>`,
    //       embeds: [new MessageEmbed().setDescription(`**لاستكمال عمليه الشراء قم بضغط علي زر
    //     "Continue" \n botType : Autoline bot**`)],
    //       components: [uuuu , kao]
    //     })



    //     await interaction.deferReply({
    //       fetchReply: true,
    //       ephemeral: true
    //     })
    //     await interaction.editReply({
    //       content: `** Done ticket created ${channelaaa} ✅**`
    //     })
    //   })

    // }
/// for gav

if (selectedOption === 'gav') {

  await interaction.guild.channels.create(`ticket-${qq.count}`, {
    type: 'GUILD_TEXT',
    permissionOverwrites: [{
        id: interaction.guild.id,
        deny: [Permissions.FLAGS.VIEW_CHANNEL],
      },
      {
        id: interaction.user.id,
        allow: [Permissions.FLAGS.VIEW_CHANNEL],
      },

    ],
    // parent: `1110577124848447619` ,
  }).then(async channelx => {
    // setTimeout(async () => {

    //   await channela.delete()

    // }, 90000);
    const closeeee = new MessageButton()
    .setCustomId('close')
    .setLabel('close')
    .setStyle('SUCCESS')
    const butx = new MessageButton()
      .setCustomId('lolx')
      .setLabel('continue')
      .setStyle('DANGER')

    const ux = new MessageActionRow()
      .addComponents(butx , closeeee)
    channelx.send({
      content: `<@${interaction.user.id}>`,
      embeds: [new MessageEmbed().setDescription(`**لاستكمال عمليه الشراء قم بضغط علي زر
    "Continue" \n botType :Giveaway bot**`)],
      components: [ux]
    })



    await interaction.deferReply({
      fetchReply: true,
      ephemeral: true
    })
    await interaction.editReply({
      content: `** Done ticket created ${channelx} ✅**`
    })
  })

}
if (selectedOption === 'line') {
  await interaction.guild.channels.create(`ticket-${qq.count}`, {
    type: 'GUILD_TEXT',
    permissionOverwrites: [{
        id: interaction.guild.id,
        deny: [Permissions.FLAGS.VIEW_CHANNEL],
      },
      {
        id: interaction.user.id,
        allow: [Permissions.FLAGS.VIEW_CHANNEL],
      },

    ],
    // parent: `1110577124848447619` ,
  }).then(async channelaaa => {
    // setTimeout(async () => {

    //   await channela.delete()

    // }, 90000);
    const closeeeee = new MessageButton()
    .setCustomId('close')
    .setLabel('close')
    .setStyle('SUCCESS')
    const buttt = new MessageButton()
      .setCustomId('lolll')
      .setLabel('continue')
      .setStyle('DANGER')

    const uuuu = new MessageActionRow()
      .addComponents(buttt , closeeeee)
    channelaaa.send({
      content: `<@${interaction.user.id}>`,
      embeds: [new MessageEmbed().setDescription(`**لاستكمال عمليه الشراء قم بضغط علي زر
    "Continue" \n botType : Autoline bot**`)],
      components: [uuuu]
    })



    await interaction.deferReply({
      fetchReply: true,
      ephemeral: true
    })
    await interaction.editReply({
      content: `** Done ticket created ${channelaaa} ✅**`
    })
  })

}

    if (selectedOption === 'sug') {

      await interaction.guild.channels.create(`ticket-${qq.count}`, {
        type: 'GUILD_TEXT',
        permissionOverwrites: [{
            id: interaction.guild.id,
            deny: [Permissions.FLAGS.VIEW_CHANNEL],
          },
          {
            id: interaction.user.id,
            allow: [Permissions.FLAGS.VIEW_CHANNEL],
          },

        ],
        // parent: `1110577124848447619` ,
      }).then(async channelaaaa => {
        // setTimeout(async () => {

        //   await channela.delete()

        // }, 90000);
        const closeeeeee = new MessageButton()
        .setCustomId('close')
        .setLabel('close')
        .setStyle('SUCCESS')

        const butttt = new MessageButton()
          .setCustomId('lollll')
          .setLabel('continue')
          .setStyle('DANGER')

        const uuuu = new MessageActionRow()
          .addComponents(butttt , closeeeeee)
        channelaaaa.send({
          content: `<@${interaction.user.id}>`,
          embeds: [new MessageEmbed().setDescription(`**لاستكمال عمليه الشراء قم بضغط علي زر
        "Continue" \n botType : suggestion bot**`)],
          components: [uuuu]
        })



        await interaction.deferReply({
          fetchReply: true,
          ephemeral: true
        })
        await interaction.editReply({
          content: `** Done ticket created ${channelaaaa} ✅**`
        })
      })

    }

    //
    if (selectedOption === 'mod') {

      await interaction.guild.channels.create(`ticket-${qq.count}`, {
        type: 'GUILD_TEXT',
        permissionOverwrites: [{
            id: interaction.guild.id,
            deny: [Permissions.FLAGS.VIEW_CHANNEL],
          },
          {
            id: interaction.user.id,
            allow: [Permissions.FLAGS.VIEW_CHANNEL],
          },

        ],
        // parent: `1110577124848447619` ,
      }).then(async channelaaaaa => {
        // setTimeout(async () => {

        //   await channela.delete()

        // }, 90000);
        const closeeeeeee = new MessageButton()
        .setCustomId('close')
        .setLabel('close')
        .setStyle('SUCCESS')
        const buttttt = new MessageButton()
          .setCustomId('lolllll')
          .setLabel('continue')
          .setStyle('DANGER')

        const uuuuu = new MessageActionRow()
          .addComponents(buttttt , closeeeeeee)
        channelaaaaa.send({
          content: `<@${interaction.user.id}>`,
          embeds: [new MessageEmbed().setDescription(`**لاستكمال عمليه الشراء قم بضغط علي زر
        "Continue" \n botType : moderation Bot**`)],
          components: [uuuuu]
        })



        await interaction.deferReply({
          fetchReply: true,
          ephemeral: true
        })
        await interaction.editReply({
          content: `** Done ticket created ${channelaaaaa} ✅**`
        })
      })

    }
    if (selectedOption === 'giv') {



      await interaction.guild.channels.create(`ticket-${qq.count}`, {
        type: 'GUILD_TEXT',
        permissionOverwrites: [{
            id: interaction.guild.id,
            deny: [Permissions.FLAGS.VIEW_CHANNEL],
          },
          {
            id: interaction.user.id,
            allow: [Permissions.FLAGS.VIEW_CHANNEL],
          },

        ],
        // parent: `1110577124848447619` ,
      }).then(async channelaaaaaa => {
        // setTimeout(async () => {

        //   await channela.delete()

        // }, 90000);
        const closeeeeeeee = new MessageButton()
        .setCustomId('close')
        .setLabel('close')
        .setStyle('SUCCESS')
        const butttttt = new MessageButton()
          .setCustomId('lollllll')
          .setLabel('continue')
          .setStyle('DANGER')

        const uuuuuu = new MessageActionRow()
          .addComponents(butttttt, closeeeeeeee)
        channelaaaaaa.send({
          content: `<@${interaction.user.id}>`,
          embeds: [new MessageEmbed().setDescription(`**لاستكمال عمليه الشراء قم بضغط علي زر
        "Continue" \n botType : ticket bot**`)],
          components: [uuuuuu]
        })



        await interaction.deferReply({
          fetchReply: true,
          ephemeral: true
        })
        await interaction.editReply({
          content: `** Done ticket created ${channelaaaaaa} ✅**`
        })
      })

    }
  }
})

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  if (interaction.customId === 'lol') {

   
      await interaction.message.edit({
        components: [
          new MessageActionRow().addComponents(
            new MessageButton()
              .setCustomId('lol')
              .setLabel('تم الضغط على الزر')
              .setStyle('PRIMARY')
              .setDisabled(true) ,
              new MessageButton()
              .setCustomId('close')
              .setLabel('لقفل الروم')
              .setStyle('DANGER')
              .setDisabled(false)

          ),
        ],
      });
      const ttt = await Owner.findOneAndUpdate({ id: interaction.guild.id });


      const owner = ttt.owner
      const tt = await proce.findOne({id : interaction.guild.id})
      await interaction.deferReply({ephemeral : true})
      await interaction.editReply({content : `**Done clicked**`})
      await interaction.channel.send({ embeds: [new MessageEmbed().setDescription(`**
      .قم بكتابه امر التحويل التالي
      c ${owner} ${tt.Price.tax}
      لديك 5 دقايق حتي تقوم بتحويل المبلغ
    **`)]})
    await interaction.channel.send({ content: `c ${owner} ${tt.Price.tax}`})
    

  }
});


//// borad
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  if (interaction.customId === 'lold') {

   
      await interaction.message.edit({
        components: [
          new MessageActionRow().addComponents(
            new MessageButton()
              .setCustomId('lold')
              .setLabel('تم الضغط على الزر')
              .setStyle('PRIMARY')
              .setDisabled(true) ,
              new MessageButton()
              .setCustomId('close')
              .setLabel('لقفل الروم')
              .setStyle('DANGER')
              .setDisabled(false)

          ),
        ],
      });
      const ttt = await Owner.findOneAndUpdate({ id: interaction.guild.id });


    const owner = ttt.owner
      const tt = await proce.findOne({id : interaction.guild.id})
      await interaction.deferReply({ephemeral : true})
      await interaction.editReply({content : `**Done clicked**`})
      await interaction.channel.send({ embeds: [new MessageEmbed().setDescription(`**
      .قم بكتابه امر التحويل التالي
      c ${owner} ${tt.Price.broadcast}
      لديك 5 دقايق حتي تقوم بتحويل المبلغ
    **`)]})
    await interaction.channel.send({ content: `c ${owner} ${tt.Price.broadcast}`})
    

  }
});

/// for gav
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  if (interaction.customId === 'lolx') {

   
      await interaction.message.edit({
        components: [
          new MessageActionRow().addComponents(
            new MessageButton()
              .setCustomId('lolx')
              .setLabel('تم الضغط على الزر')
              .setStyle('PRIMARY')
              .setDisabled(true),
              new MessageButton()
              .setCustomId('close')
              .setLabel('لقفل الروم')
              .setStyle('DANGER')
              .setDisabled(false)
          ),
        ],
      });
      const ttt = await Owner.findOneAndUpdate({ id: interaction.guild.id });


      const owner = ttt.owner
      const tt = await proce.findOne({id : interaction.guild.id})
      await interaction.deferReply({ephemeral : true})
      await interaction.editReply({content : `**Done clicked**`})
      await interaction.channel.send({ embeds: [new MessageEmbed().setDescription(`**
      .قم بكتابه امر التحويل التالي
      c ${owner} ${tt.Price.giveaway}
      لديك 5 دقايق حتي تقوم بتحويل المبلغ
    **`)]})
    await interaction.channel.send({ content: `c ${owner} ${tt.Price.giveaway}`})
 
    

  }
});

/// say 

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  if (interaction.customId === 'lolq') {

   
      await interaction.message.edit({
        components: [
          new MessageActionRow().addComponents(
            new MessageButton()
              .setCustomId('lolq')
              .setLabel('تم الضغط على الزر')
              .setStyle('PRIMARY')
              .setDisabled(true),
              new MessageButton()
              .setCustomId('close')
              .setLabel('لقفل الروم')
              .setStyle('DANGER')
              .setDisabled(false)
          ),
        ],
      });
      const ttt = await Owner.findOneAndUpdate({ id: interaction.guild.id });


    const owner = ttt.owner
      const tt = await proce.findOne({id : interaction.guild.id})
      await interaction.deferReply({ephemeral : true})
      await interaction.editReply({content : `**Done clicked**`})
      await interaction.channel.send({ embeds: [new MessageEmbed().setDescription(`**
      .قم بكتابه امر التحويل التالي
      c ${owner} ${tt.Price.say}
      لديك 5 دقايق حتي تقوم بتحويل المبلغ
    **`)]})
    await interaction.channel.send({ content: `c ${owner} ${tt.Price.say}`})
 
    

  }
});

/// come
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  if (interaction.customId === 'lole') {

   
      await interaction.message.edit({
        components: [
          new MessageActionRow().addComponents(
            new MessageButton()
              .setCustomId('lole')
              .setLabel('تم الضغط على الزر')
              .setStyle('PRIMARY')
              .setDisabled(true),
              new MessageButton()
              .setCustomId('close')
              .setLabel('لقفل الروم')
              .setStyle('DANGER')
              .setDisabled(false)
          ),
        ],
      });
      const ttt = await Owner.findOneAndUpdate({ id: interaction.guild.id });


      const owner = ttt.owner
      const tt = await proce.findOne({id : interaction.guild.id})
      await interaction.deferReply({ephemeral : true})
      await interaction.editReply({content : `**Done clicked**`})
      await interaction.channel.send({ embeds: [new MessageEmbed().setDescription(`**
      .قم بكتابه امر التحويل التالي
      c ${owner} ${tt.Price.come}
      لديك 5 دقايق حتي تقوم بتحويل المبلغ
    **`)]})
    await interaction.channel.send({ content: `c ${owner} ${tt.Price.come}`})
 
    

  }
});

/// for giv
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  if (interaction.customId === 'lollllll') {

   
      await interaction.message.edit({
        components: [
          new MessageActionRow().addComponents(
            new MessageButton()
              .setCustomId('lollllll')
              .setLabel('تم الضغط على الزر')
              .setStyle('PRIMARY')
              .setDisabled(true),
              new MessageButton()
              .setCustomId('close')
              .setLabel('لقفل الروم')
              .setStyle('DANGER')
              .setDisabled(false)
          ),
        ],
      });
      const ttt = await Owner.findOneAndUpdate({ id: interaction.guild.id });


      const owner = ttt.owner
      const tt = await proce.findOne({id : interaction.guild.id})
      await interaction.deferReply({ephemeral : true})
      await interaction.editReply({content : `**Done clicked**`})
      await interaction.channel.send({ embeds: [new MessageEmbed().setDescription(`**
      .قم بكتابه امر التحويل التالي
      c ${owner} ${tt.Price.ticket}
      لديك 5 دقايق حتي تقوم بتحويل المبلغ
    **`)]})
    await interaction.channel.send({ content: `c ${owner} ${tt.Price.ticket}`})
 
    

  }
});

//for mod

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  if (interaction.customId === 'lolllll') {

   
      await interaction.message.edit({
        components: [
          new MessageActionRow().addComponents(
            new MessageButton()
              .setCustomId('lolllll')
              .setLabel('تم الضغط على الزر')
              .setStyle('PRIMARY')
              .setDisabled(true),
              new MessageButton()
              .setCustomId('close')
              .setLabel('لقفل الروم')
              .setStyle('DANGER')
              .setDisabled(false)
          ),
        ],
      });
      const ttt = await Owner.findOneAndUpdate({ id: interaction.guild.id });


      const owner = ttt.owner
      const tt = await proce.findOne({id : interaction.guild.id})
      await interaction.deferReply({ephemeral : true})
      await interaction.editReply({content : `**Done clicked**`})
      await interaction.channel.send({ embeds: [new MessageEmbed().setDescription(`**
      .قم بكتابه امر التحويل التالي
      c ${owner} ${tt.Price.moderation}
      لديك 5 دقايق حتي تقوم بتحويل المبلغ
    **`)]})
    await interaction.channel.send({ content: `c ${owner} ${tt.Price.moderation}`})
 
    

  }
});
//// sug 
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  if (interaction.customId === 'lollll') {

   
      await interaction.message.edit({
        components: [
          new MessageActionRow().addComponents(
            new MessageButton()
              .setCustomId('lollll')
              .setLabel('تم الضغط على الزر')
              .setStyle('PRIMARY')
              .setDisabled(true),
              new MessageButton()
              .setCustomId('close')
              .setLabel('لقفل الروم')
              .setStyle('DANGER')
              .setDisabled(false)
          ),
        ],
      });
      const ttt = await Owner.findOneAndUpdate({ id: interaction.guild.id });


      const owner = ttt.owner
      const tt = await proce.findOne({id : interaction.guild.id})
      await interaction.deferReply({ephemeral : true})
      await interaction.editReply({content : `**Done clicked**`})
      await interaction.channel.send({ embeds: [new MessageEmbed().setDescription(`**
      .قم بكتابه امر التحويل التالي
      c ${owner} ${tt.Price.suggestion}
      لديك 5 دقايق حتي تقوم بتحويل المبلغ
    **`)]})
    await interaction.channel.send({ content: `c ${owner} ${tt.Price.suggestion}`})
    

  }
});


///// autoline 
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  if (interaction.customId === 'lolll') {

   
      await interaction.message.edit({
        components: [
          new MessageActionRow().addComponents(
            new MessageButton()
              .setCustomId('lolll')
              .setLabel('تم الضغط على الزر')
              .setStyle('PRIMARY')
              .setDisabled(true),
              new MessageButton()
              .setCustomId('close')
              .setLabel('لقفل الروم')
              .setStyle('DANGER')
              .setDisabled(false)
          ),
        ],
      });
      let ttt = await Owner.findOneAndUpdate({ id: interaction.guild.id });
    

  let owner = ttt.owner


      const tt = await proce.findOne({id : interaction.guild.id})
      await interaction.deferReply({ephemeral : true})
      await interaction.editReply({content : `**Done clicked**`})
      await interaction.channel.send({ embeds: [new MessageEmbed().setDescription(`**
      .قم بكتابه امر التحويل التالي
      c ${owner} ${tt.Price.autoline}
      لديك 5 دقايق حتي تقوم بتحويل المبلغ
    **`)]})
    await interaction.channel.send({ content: `c ${owner} ${tt.Price.autoline}`})
    

  }
});


const buttonCooldown = 60000; // 1 minute cooldown

const buttonTimestamps = new Map();

client.on('messageCreate', async message => {
  if (message.author.bot) return;
  const rr = await prece.findOne({id : message.guild.id})
  const ttt = await Owner.findOne({ id: message.guild.id });


  const owner = ttt.owner
  let price_without = `${rr.Price.tax}` // boost tool
  let ownerId = `${owner}`
  const probotId = '282859044593598464'
  const role = message.guild.roles.cache.get('1123483457360773190')
  let trans_msg = `**:moneybag: | ${message.author.username}, has transferred \`$${price_without}\` to <@!${ownerId}> **`;
  let collect2 = await message.channel.awaitMessages({
    filter: mm => mm.author.id === probotId && mm.content === trans_msg,
    max: 1,
    time: 0
  }).catch(() => 0);
  collect2 = collect2.first();
  if (!collect2) return;
  if (collect2.content != trans_msg) return;

  const lastTimestamp = buttonTimestamps.get(message.author.id) || 0;
  const now = Date.now();

  if (now - lastTimestamp >= buttonCooldown) {
    const butt = new MessageButton()
      .setCustomId('ki')
      .setLabel('click')
      .setStyle('DANGER')

    const roww = new MessageActionRow()
      .addComponents(butt)
    message.channel.send({content : `**اضغط على الزر وقم باضافة التوكن والبريفكس فى المكان المحدد لهما**` ,
      components: [roww]
    })

    buttonTimestamps.set(message.author.id, now);
  }
});

//// say 
client.on('messageCreate', async message => {
  if (message.author.bot) return;
const rr = await prece.findOne({id : message.guild.id})
const ttt = await Owner.findOne({ id: message.guild.id });


const owner = ttt.owner

  let price_without = `${rr.Price.say}` // boost tool
  let ownerId = `${owner}`
  const probotId = '282859044593598464'
  const role = message.guild.roles.cache.get('1123483457360773190')
  let trans_msg = `**:moneybag: | ${message.author.username}, has transferred \`$${price_without}\` to <@!${ownerId}> **`;
  let collect2 = await message.channel.awaitMessages({
    filter: mm => mm.author.id === probotId && mm.content === trans_msg,
    max: 1,
    time: 0
  }).catch(() => 0);
  collect2 = collect2.first();
  if (!collect2) return;
  if (collect2.content != trans_msg) return;

  const lastTimestamp = buttonTimestamps.get(message.author.id) || 0;
  const now = Date.now();

  if (now - lastTimestamp >= buttonCooldown) {
    const buttq = new MessageButton()
      .setCustomId('kiq')
      .setLabel('click')
      .setStyle('DANGER')

   

    const rowwq = new MessageActionRow()
      .addComponents(buttq)
    message.channel.send({content : `**اضغط على الزر وقم باضافة التوكن والبريفكس فى المكان المحدد لهما**` ,
      components: [rowwq]
    })
    // const tt = await loggg.findOne({ id: message.guild.id });
    // const channelMention = tt.channel;
    // const channelId = channelMention.match(/\d+/)[0];
    // const channel = await message.guild.channels.cache.get(channelId);
    // if (!channel) {
    //   console.log(`Error: Unable to retrieve channel with ID ${channelId}`);
    //   return;
    // }
    // const user = message.author.username;
    // await channel.send({
    //   content: `**Say bot has been purchased by ${user} Enjoy ... **`,
    // });
    buttonTimestamps.set(message.author.id, now);
  }
});

////borad
client.on('messageCreate', async message => {
  if (message.author.bot) return;
  const rr = await prece.findOne({id : message.guild.id})
  const ttt = await Owner.findOne({ id: message.guild.id });


  const owner = ttt.owner
  let price_without = `${rr.Price.broadcast}` // boost tool
  let ownerId = `${owner}`
  const probotId = '282859044593598464'
  const role = message.guild.roles.cache.get('1123483457360773190')
  let trans_msg = `**:moneybag: | ${message.author.username}, has transferred \`$${price_without}\` to <@!${ownerId}> **`;
  let collect2 = await message.channel.awaitMessages({
    filter: mm => mm.author.id === probotId && mm.content === trans_msg,
    max: 1,
    time: 0
  }).catch(() => 0);
  collect2 = collect2.first();
  if (!collect2) return;
  if (collect2.content != trans_msg) return;

  const lastTimestamp = buttonTimestamps.get(message.author.id) || 0;
  const now = Date.now();

  if (now - lastTimestamp >= buttonCooldown) {
    const buttqd = new MessageButton()
      .setCustomId('kid')
      .setLabel('click')
      .setStyle('DANGER')

   

    const rowwqd = new MessageActionRow()
      .addComponents(buttqd)
    message.channel.send({content : `**اضغط على الزر وقم باضافة التوكن والبريفكس فى المكان المحدد لهما**` ,
      components: [rowwqd]
    })
    // const tt = await loggg.findOne({ id:message.guild.id });
    // const channelMention = tt.channel;
    // const channelId = channelMention.match(/\d+/)[0];
    // const channel = await message.guild.channels.cache.get(channelId);
    // if (!channel) {
    //   console.log(`Error: Unable to retrieve channel with ID ${channelId}`);
    //   return;
    // }
    // const user = message.author.username;
    // await channel.send({
    //   content: `**Broadcast bot has been purchased by ${user} Enjoy ... **`,
    // });
    buttonTimestamps.set(message.author.id, now);
  }
});

/////come
client.on('messageCreate', async message => {
  if (message.author.bot) return;
  const rr = await prece.findOne({id : message.guild.id})
  const ttt = await Owner.findOne({ id: message.guild.id });


  const owner = ttt.owner
  let price_without = `${rr.Price.come}` // boost tool
  let ownerId = `${owner}`
  const probotId = '282859044593598464'
  const role = message.guild.roles.cache.get('1123483457360773190')
  let trans_msg = `**:moneybag: | ${message.author.username}, has transferred \`$${price_without}\` to <@!${ownerId}> **`;
  let collect2 = await message.channel.awaitMessages({
    filter: mm => mm.author.id === probotId && mm.content === trans_msg,
    max: 1,
    time: 0
  }).catch(() => 0);
  collect2 = collect2.first();
  if (!collect2) return;
  if (collect2.content != trans_msg) return;

  const lastTimestamp = buttonTimestamps.get(message.author.id) || 0;
  const now = Date.now();

  if (now - lastTimestamp >= buttonCooldown) {
    const butte = new MessageButton()
      .setCustomId('kie')
      .setLabel('click')
      .setStyle('DANGER')


   
    const rowwe = new MessageActionRow()
      .addComponents(butte)
    message.channel.send({content : `**اضغط على الزر وقم باضافة التوكن والبريفكس فى المكان المحدد لهما**` ,
      components: [rowwe]
    })
    // const tt = await loggg.findOne({ id: message.guild.id });
    // const channelMention = tt.channel;
    // const channelId = channelMention.match(/\d+/)[0];
    // const channel = await message.guild.channels.cache.get(channelId);
    // if (!channel) {
    //   console.log(`Error: Unable to retrieve channel with ID ${channelId}`);
    //   return;
    // }
    // const user = message.author.username;
    // await channel.send({
    //   content: `**Come bot has been purchased by ${user} Enjoy ... **`,
    // });
    buttonTimestamps.set(message.author.id, now);
  }
});

/// for tick
client.on('messageCreate', async message => {
  if (message.author.bot) return;
  const rr = await prece.findOne({id : message.guild.id})
  const ttt = await Owner.findOne({ id: message.guild.id });


  const owner = ttt.owner
  let price_without = `${rr.Price.ticket}` // boost tool
  let ownerId = `${owner}`
  const probotId = '282859044593598464'
  const role = message.guild.roles.cache.get('1123483457360773190')
  let trans_msg = `**:moneybag: | ${message.author.username}, has transferred \`$${price_without}\` to <@!${ownerId}> **`;
  let collect2 = await message.channel.awaitMessages({
    filter: mm => mm.author.id === probotId && mm.content === trans_msg,
    max: 1,
    time: 0
  }).catch(() => 0);
  collect2 = collect2.first();
  if (!collect2) return;
  if (collect2.content != trans_msg) return;

  const lastTimestamp = buttonTimestamps.get(message.author.id) || 0;
  const now = Date.now();

  if (now - lastTimestamp >= buttonCooldown) {
    const butttttt = new MessageButton()
      .setCustomId('kiiiiii')
      .setLabel('click')
      .setStyle('DANGER')

    const rowwwwww = new MessageActionRow()
      .addComponents(butttttt)
    message.channel.send({content : `**اضغط على الزر وقم باضافة التوكن والبريفكس فى المكان المحدد لهما**` ,
      components: [rowwwwww]
    })
    // const tt = await loggg.findOne({ id: message.guild.id });
    // const channelMention = tt.channel;
    // const channelId = channelMention.match(/\d+/)[0];
    // const channel = await message.guild.channels.cache.get(channelId);
    // if (!channel) {
    //   console.log(`Error: Unable to retrieve channel with ID ${channelId}`);
    //   return;
    // }
    // const user = message.author.username;
    // await channel.send({
    //   content: `**Ticket bot has been purchased by ${user} Enjoy ... **`,
    // });

    buttonTimestamps.set(message.author.id, now);
  }
});


//// for gav = 7
// client.on('messageCreate', async message => {
//   if (message.author.bot) return;

//   let price_without = '7' // boost tool
//   let ownerId = "472444590868135949"
//   const probotId = '282859044593598464'
//   const role = message.guild.roles.cache.get('1123483457360773190')
//   let trans_msg = `**:moneybag: | ${message.author.username}, has transferred \`$${price_without}\` to <@!${ownerId}> **`;
//   let collect2 = await message.channel.awaitMessages({
//     filter: mm => mm.author.id === probotId && mm.content === trans_msg,
//     max: 1,
//     time: 0
//   }).catch(() => 0);
//   collect2 = collect2.first();
//   if (!collect2) return;
//   if (collect2.content != trans_msg) return;

//   const lastTimestamp = buttonTimestamps.get(message.author.id) || 0;
//   const now = Date.now();

//   if (now - lastTimestamp >= buttonCooldown) {
//     const butt = new MessageButton()
//       .setCustomId('kii')
//       .setLabel('click')
//       .setStyle('DANGER')

//     const roww = new MessageActionRow()
//       .addComponents(butt)
//     message.channel.send({content : `**اضغط على الزر وقم باضافة التوكن والبريفكس فى المكان المحدد لهما**` ,
//       components: [roww]
//     })

//     buttonTimestamps.set(message.author.id, now);
//   }
// });

/// for givaway= 4
client.on('messageCreate', async message => {
  if (message.author.bot) return;
  const rr = await prece.findOne({id : message.guild.id})
  const ttt = await Owner.findOne({ id: message.guild.id });


  const owner = ttt.owner
  let price_without = `${rr.Price.giveaway}` // boost tool
  let ownerId = `${owner}`
  const probotId = '282859044593598464'
  const role = message.guild.roles.cache.get('1123483457360773190')
  let trans_msg = `**:moneybag: | ${message.author.username}, has transferred \`$${price_without}\` to <@!${ownerId}> **`;
  let collect2 = await message.channel.awaitMessages({
    filter: mm => mm.author.id === probotId && mm.content === trans_msg,
    max: 1,
    time: 0
  }).catch(() => 0);
  collect2 = collect2.first();
  if (!collect2) return;
  if (collect2.content != trans_msg) return;

  const lastTimestamp = buttonTimestamps.get(message.author.id) || 0;
  const now = Date.now();

  if (now - lastTimestamp >= buttonCooldown) {
    const butx = new MessageButton()
      .setCustomId('kix')
      .setLabel('click')
      .setStyle('DANGER')

    const rowx = new MessageActionRow()
      .addComponents(butx)
    message.channel.send({content : `**اضغط على الزر وقم باضافة التوكن والبريفكس فى المكان المحدد لهما**` ,
      components: [rowx]
    })
    // const tt = await loggg.findOne({ id: message.guild.id });
    // const channelMention = tt.channel;
    // const channelId = channelMention.match(/\d+/)[0];
    // const channel = await message.guild.channels.cache.get(channelId);
    // if (!channel) {
    //   console.log(`Error: Unable to retrieve channel with ID ${channelId}`);
    //   return;
    // }
    // const user = message.author.username;
    // await channel.send({
    //   content: `**Giveaway bot has been purchased by ${user} Enjoy ... **`,
    // });

    buttonTimestamps.set(message.author.id, now);
  }
});
///for mod = 6
client.on('messageCreate', async message => {
  if (message.author.bot) return;
  const rr = await prece.findOne({id : message.guild.id})
  const ttt = await Owner.findOne({ id: message.guild.id });


  const owner = ttt.owner
  let price_without = `${rr.Price.moderation}` // boost tool
  let ownerId = `${owner}`
  const probotId = '282859044593598464'
  const role = message.guild.roles.cache.get('1123483457360773190')
  let trans_msg = `**:moneybag: | ${message.author.username}, has transferred \`$${price_without}\` to <@!${ownerId}> **`;
  let collect2 = await message.channel.awaitMessages({
    filter: mm => mm.author.id === probotId && mm.content === trans_msg,
    max: 1,
    time: 0
  }).catch(() => 0);
  collect2 = collect2.first();
  if (!collect2) return;
  if (collect2.content != trans_msg) return;

  const lastTimestamp = buttonTimestamps.get(message.author.id) || 0;
  const now = Date.now();

  if (now - lastTimestamp >= buttonCooldown) {
    const buttttt = new MessageButton()
      .setCustomId('kiiiii')
      .setLabel('click')
      .setStyle('DANGER')
 
    const rowwwww = new MessageActionRow()
      .addComponents(buttttt)
    message.channel.send({content : `**اضغط على الزر وقم باضافة التوكن والبريفكس فى المكان المحدد لهما**` ,
      components: [rowwwww]
    })
    // const tt = await loggg.findOne({ id: message.guild.id });
    // const channelMention = tt.channel;
    // const channelId = channelMention.match(/\d+/)[0];
    // const channel = await message.guild.channels.cache.get(channelId);
    // if (!channel) {
    //   console.log(`Error: Unable to retrieve channel with ID ${channelId}`);
    //   return;
    // }
    // const user = message.author.username;
    // await channel.send({
    //   content: `**Moderation bot has been purchased by ${user} Enjoy ... **`,
    // });
    buttonTimestamps.set(message.author.id, now);
  }
});


///// for sug = 8

client.on('messageCreate', async message => {
  if (message.author.bot) return;
  const rr = await prece.findOne({id : message.guild.id})
  const ttt = await Owner.findOne({ id: message.guild.id });


  const owner = ttt.owner
  let price_without = `${rr.Price.suggestion}` // boost tool
  let ownerId = `${owner}`
  const probotId = '282859044593598464'
  const role = message.guild.roles.cache.get('1123483457360773190')
  let trans_msg = `**:moneybag: | ${message.author.username}, has transferred \`$${price_without}\` to <@!${ownerId}> **`;
  let collect2 = await message.channel.awaitMessages({
    filter: mm => mm.author.id === probotId && mm.content === trans_msg,
    max: 1,
    time: 0
  }).catch(() => 0);
  collect2 = collect2.first();
  if (!collect2) return;
  if (collect2.content != trans_msg) return;

  const lastTimestamp = buttonTimestamps.get(message.author.id) || 0;
  const now = Date.now();

  if (now - lastTimestamp >= buttonCooldown) {
    const butttt = new MessageButton()
      .setCustomId('kiiii')
      .setLabel('click')
      .setStyle('DANGER')

    const rowwww = new MessageActionRow()
      .addComponents(butttt)
    message.channel.send({content : `**اضغط على الزر وقم باضافة التوكن والبريفكس فى المكان المحدد لهما**` ,
      components: [rowwww]
    })
    // const tt = await loggg.findOne({ id: message.guild.id });
    // const channelMention = tt.channel;
    // const channelId = channelMention.match(/\d+/)[0];
    // const channel = await message.guild.channels.cache.get(channelId);
    // if (!channel) {
    //   console.log(`Error: Unable to retrieve channel with ID ${channelId}`);
    //   return;
    // }
    // const user = message.author.username;
    // await channel.send({
    //   content: `**Suggestion bot has been purchased by ${user} Enjoy ... **`,
    // });
    buttonTimestamps.set(message.author.id, now);
  }
});
/// for autoline

client.on('messageCreate', async message => {
  if (message.author.bot) return;
  const rr = await prece.findOne({id : message.guild.id})
  const ttt = await Owner.findOne({ id:message.guild.id });


  const owner = ttt.owner
  let price_without = `${rr.Price.autoline}` // boost tool
  let ownerId = `${owner}`
  const probotId = '282859044593598464'
  const role = message.guild.roles.cache.get('1123483457360773190')
  let trans_msg = `**:moneybag: | ${message.author.username}, has transferred \`$${price_without}\` to <@!${ownerId}> **`;
  let collect2 = await message.channel.awaitMessages({
    filter: mm => mm.author.id === probotId && mm.content === trans_msg,
    max: 1,
    time: 0
  }).catch(() => 0);
  collect2 = collect2.first();
  if (!collect2) return;
  if (collect2.content != trans_msg) return;

  const lastTimestamp = buttonTimestamps.get(message.author.id) || 0;
  const now = Date.now();

  if (now - lastTimestamp >= buttonCooldown) {
    const buttt = new MessageButton()
      .setCustomId('kiii')
      .setLabel('click')
      .setStyle('DANGER')

    const rowww = new MessageActionRow()
      .addComponents(buttt)
    message.channel.send({content : `**اضغط على الزر وقم باضافة التوكن والبريفكس فى المكان المحدد لهما**` ,
      components: [rowww]
    })
   /

    buttonTimestamps.set(message.author.id, now);
  }
});
/// autoline

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return
  if (interaction.customId === 'kiii') {
    const modalll = new Modal()
      .setCustomId('myModalll')
      .setTitle('My Modal');
    const tokennn = new TextInputComponent()
      .setCustomId('tokennn')
      // The label is the prompt the user sees for this input
      .setLabel("bot token")
      // Short means only a single line of text
      .setStyle('SHORT');
    const prefixxx = new TextInputComponent()
      .setCustomId('prefixxx')
      .setLabel("bot prefix")
      // Paragraph means multiple lines of text.
      .setStyle('SHORT');
    // An action row only holds one text input,
    // so you need one action row per text input.
    const firstActionRowww = new MessageActionRow().addComponents(tokennn);
    const secondActionRowww = new MessageActionRow().addComponents(prefixxx);
    // Add inputs to the modal
    modalll.addComponents(firstActionRowww, secondActionRowww);
    // Show the modal to the user
    await interaction.showModal(modalll);
  }
})
/// for gav 
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return
  if (interaction.customId === 'kix') {
    const modalx = new Modal()
      .setCustomId('myModalx')
      .setTitle('My Modal');
    const tokenx = new TextInputComponent()
      .setCustomId('tokenx')
      // The label is the prompt the user sees for this input
      .setLabel("bot token")
      // Short means only a single line of text
      .setStyle('SHORT');
    const prefic = new TextInputComponent()
      .setCustomId('prefic')
      .setLabel("bot prefix")
      // Paragraph means multiple lines of text.
      .setStyle('SHORT');
    // An action row only holds one text input,
    // so you need one action row per text input.
    const firstActionRowx = new MessageActionRow().addComponents(tokenx);
    const secondActionRowx = new MessageActionRow().addComponents(prefic);
    // Add inputs to the modal
    modalx.addComponents(firstActionRowx, secondActionRowx);
    // Show the modal to the user
    await interaction.showModal(modalx);
  }
})

//// say 
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return
  if (interaction.customId === 'kiq') {
    const modalq = new Modal()
      .setCustomId('myModalq')
      .setTitle('My Modal');
    const tokenq = new TextInputComponent()
      .setCustomId('tokenq')
      // The label is the prompt the user sees for this input
      .setLabel("bot token")
      // Short means only a single line of text
      .setStyle('SHORT');
    const prefiq = new TextInputComponent()
      .setCustomId('prefiq')
      .setLabel("bot prefix")
      // Paragraph means multiple lines of text.
      .setStyle('SHORT');
    // An action row only holds one text input,
    // so you need one action row per text input.
    const firstActionRowq = new MessageActionRow().addComponents(tokenq);
    const secondActionRowq = new MessageActionRow().addComponents(prefiq);
    // Add inputs to the modal
    modalq.addComponents(firstActionRowq, secondActionRowq);
    // Show the modal to the user
    await interaction.showModal(modalq);
  }
})

////come
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return
  if (interaction.customId === 'kie') {
    const modale = new Modal()
      .setCustomId('myModale')
      .setTitle('My Modal');
    const tokene = new TextInputComponent()
      .setCustomId('tokene')
      // The label is the prompt the user sees for this input
      .setLabel("bot token")
      // Short means only a single line of text
      .setStyle('SHORT');
    const prefie = new TextInputComponent()
      .setCustomId('prefie')
      .setLabel("bot prefix")
      // Paragraph means multiple lines of text.
      .setStyle('SHORT');
    // An action row only holds one text input,
    // so you need one action row per text input.
    const firstActionRowe = new MessageActionRow().addComponents(tokene);
    const secondActionRowe = new MessageActionRow().addComponents(prefie);
    // Add inputs to the modal
    modale.addComponents(firstActionRowe, secondActionRowe);
    // Show the modal to the user
    await interaction.showModal(modale);
  }
})


// for giv

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return
  if (interaction.customId === 'kiiiiii') {
    const modallllll = new Modal()
      .setCustomId('myModallllll')
      .setTitle('My Modal');
    const tokennnnnn = new TextInputComponent()
      .setCustomId('tokennnnnn')
      // The label is the prompt the user sees for this input
      .setLabel("bot token")
      // Short means only a single line of text
      .setStyle('SHORT');
    const prefixxxxxx = new TextInputComponent()
      .setCustomId('prefixxxxxx')
      .setLabel("bot prefix")
      // Paragraph means multiple lines of text.
      .setStyle('SHORT');
    // An action row only holds one text input,
    // so you need one action row per text input.
    const firstActionRowwwwww = new MessageActionRow().addComponents(tokennnnnn);
    const secondActionRowwwwww = new MessageActionRow().addComponents(prefixxxxxx);
    // Add inputs to the modal
    modallllll.addComponents(firstActionRowwwwww, secondActionRowwwwww);
    // Show the modal to the user
    await interaction.showModal(modallllll);
  }
})

//// for mod
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return
  if (interaction.customId === 'kiiiii') {
    const modalllll = new Modal()
      .setCustomId('myModalllll')
      .setTitle('My Modal');
    const tokennnnn = new TextInputComponent()
      .setCustomId('tokennnnn')
      // The label is the prompt the user sees for this input
      .setLabel("bot token")
      // Short means only a single line of text
      .setStyle('SHORT');
    const prefixxxxx = new TextInputComponent()
      .setCustomId('prefixxxxx')
      .setLabel("bot prefix")
      // Paragraph means multiple lines of text.
      .setStyle('SHORT');
    // An action row only holds one text input,
    // so you need one action row per text input.
    const firstActionRowwwww = new MessageActionRow().addComponents(tokennnnn);
    const secondActionRowwwww = new MessageActionRow().addComponents(prefixxxxx);
    // Add inputs to the modal
    modalllll.addComponents(firstActionRowwwww, secondActionRowwwww);
    // Show the modal to the user
    await interaction.showModal(modalllll);
  }
})

//// for sug
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return
  if (interaction.customId === 'kiiii') {
    const modallll = new Modal()
      .setCustomId('myModallll')
      .setTitle('My Modal');
    const tokennnn = new TextInputComponent()
      .setCustomId('tokennnn')
      // The label is the prompt the user sees for this input
      .setLabel("bot token")
      // Short means only a single line of text
      .setStyle('SHORT');
    const prefixxxx = new TextInputComponent()
      .setCustomId('prefixxxx')
      .setLabel("bot prefix")
      // Paragraph means multiple lines of text.
      .setStyle('SHORT');
    // An action row only holds one text input,
    // so you need one action row per text input.
    const firstActionRowwww = new MessageActionRow().addComponents(tokennnn);
    const secondActionRowwww = new MessageActionRow().addComponents(prefixxxx);
    // Add inputs to the modal
    modallll.addComponents(firstActionRowwww, secondActionRowwww);
    // Show the modal to the user
    await interaction.showModal(modallll);
  }
})

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return
  if (interaction.customId === 'ki') {
    const modal = new Modal()
      .setCustomId('myModal')
      .setTitle('My Modal');
    const token = new TextInputComponent()
      .setCustomId('token')
      // The label is the prompt the user sees for this input
      .setLabel("bot token")
      // Short means only a single line of text
      .setStyle('SHORT');
    const prefix = new TextInputComponent()
      .setCustomId('prefix')
      .setLabel("bot prefix")
      // Paragraph means multiple lines of text.
      .setStyle('SHORT');
    // An action row only holds one text input,
    // so you need one action row per text input.
    const firstActionRow = new MessageActionRow().addComponents(token);
    const secondActionRow = new MessageActionRow().addComponents(prefix);
    // Add inputs to the modal
    modal.addComponents(firstActionRow, secondActionRow);
    // Show the modal to the user
    await interaction.showModal(modal);
  }
})


////braod

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return
  if (interaction.customId === 'kid') {
    const modald = new Modal()
      .setCustomId('myModald')
      .setTitle('My Modal');
    const tokend = new TextInputComponent()
      .setCustomId('tokend')
      // The label is the prompt the user sees for this input
      .setLabel("bot token")
      // Short means only a single line of text
      .setStyle('SHORT');
    const prefixd = new TextInputComponent()
      .setCustomId('prefixd')
      .setLabel("bot prefix")
      // Paragraph means multiple lines of text.
      .setStyle('SHORT');
    // An action row only holds one text input,
    // so you need one action row per text input.
    const firstActionRowd = new MessageActionRow().addComponents(tokend);
    const secondActionRowd = new MessageActionRow().addComponents(prefixd);
    // Add inputs to the modal
    modald.addComponents(firstActionRowd, secondActionRowd);
    // Show the modal to the user
    await interaction.showModal(modald);
  }
})


////
const logData = require('./log.json');
const line = require('./models/line.js');

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  if (interaction.customId === 'myModalll') {
    // Get the data entered by the user
    const tokennn = interaction.fields.getTextInputValue('tokennn');
    const prefixxx = interaction.fields.getTextInputValue('prefixxx');

    line.findOne({id : interaction.guild.id} , async (data) => {
      if (!data) {
        line.create (
          {
            id : interaction.guild.id , 
            token : tokennn , 
            prefix : prefixxx
  
          }
        )
      }
    })
    
   

    console.log(tokennn, prefixxx);
    const tt = await logg.findOne({ id: interaction.guild.id });
    const channelMention = tt.channel;
    const channelId = channelMention.match(/\d+/)[0];
    const channel = await interaction.guild.channels.cache.get(channelId);

    const ttt = await loggg.findOne({id : interaction.guild.id})
    const channell = await interaction.guild.channels.cache.get(ttt.channel);
    const userr = interaction.user.username;
    await channell.send({content : `**Line bot has been bought by ${userr}**`})
    await channel.send({
      content: `**Done purchased Line bot ${tokennn} \n prefix :- ${prefixxx} \n Id : ${myId} \n Purshased by : ${interaction.user}**`,
    });
    const user = interaction.user
    user.send({ content: `**${user} Done purchased ${tokennn} \n prefix :- ${prefixxx} \n برجاء الانتظار حتى يكون بوتك أونلاين **` })
    await interaction.update({
      content: `**Done purchased  ${tokennn} \n prefix :- ${prefixxx}** `,
      components : [new MessageActionRow().addComponents (
        new MessageButton()
        .setCustomId('kiii')
        .setLabel('تم الضغط')
        .setStyle('DANGER')
        .setDisabled(true)
      )]
    });
  }
});


/// borad
const broad = require('./models/broad.js');

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  if (interaction.customId === 'myModald') {
    // Get the data entered by the user
    const tokend = interaction.fields.getTextInputValue('tokend');
    const prefixd = interaction.fields.getTextInputValue('prefixd');

    broad.findOne({id : interaction.guild.id} , async (data) => {
      if (!data) {
        broad.create (
          {
            id : interaction.guild.id , 
            token : tokend , 
            prefix : prefixd
  
          }
        )
      }
    })
    
   

    console.log(tokend, prefixd);
    const tt = await logg.findOne({ id: interaction.guild.id });
    const channelMention = tt.channel;
    const channelId = channelMention.match(/\d+/)[0];
    const channel = await interaction.guild.channels.cache.get(channelId);
    const ttt = await loggg.findOne({id : interaction.guild.id})
    const channell = await interaction.guild.channels.cache.get(ttt.channel);
    const userr = interaction.user.username;
    await channell.send({content : `**Broadcast bot has been bought by ${userr}**`})
    await channel.send({
      content: `**Done purchased Broadcast bot ${tokend} \n prefix :- ${prefixd} \n Id : ${myId} \n Purshased by : ${interaction.user}**`,
    });
    const user = interaction.user
    user.send({  content: `**Done purchased ${tokend} \n prefix : ${prefixd}  \n برجاء الانتظار حتى يكون بوتك أونلاين **` })
    await interaction.update({
      content: `**Done purchased Broadcast bot ${tokend} \n prefix : ${prefixd} **`,
      components : [new MessageActionRow().addComponents (
        new MessageButton()
        .setCustomId('kid')
        .setLabel('تم الضغط')
        .setStyle('DANGER')
        .setDisabled(true)
      )]
    });
  }
});


////say 
const say = require('./models/say.js');

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  if (interaction.customId === 'myModalq') {
    // Get the data entered by the user
    const tokenq = interaction.fields.getTextInputValue('tokenq');
    const prefiq = interaction.fields.getTextInputValue('prefiq');

    say.findOne({id : interaction.guild.id} , async (data) => {
      if (!data) {
        say.create (
          {
            id : interaction.guild.id , 
            token : tokenq , 
            prefix : prefiq
  
          }
        )
      }
    })
    
   

    console.log(tokenq, prefiq);
    const tt = await logg.findOne({ id: interaction.guild.id });
    const channelMention = tt.channel;
    const channelId = channelMention.match(/\d+/)[0];
    const channel = await interaction.guild.channels.cache.get(channelId);
    const ttt = await loggg.findOne({id : interaction.guild.id})
    const channell = await interaction.guild.channels.cache.get(ttt.channel);
    const userr = interaction.user.username;
    await channell.send({content : `**Say bot has been bought by ${userr}**`})
    await channel.send({
      content: `**Done purchased Say bot  ${tokenq} \n prefix :- ${prefiq} \n Id : ${myId} \n Purshased by : ${interaction.user}**`,
    });
    const user = interaction.user
    user.send({  content: `**Done purchased ${tokenq} \n prefix : ${prefiq}  \n برجاء الانتظار حتى يكون بوتك أونلاين  **` })
    await interaction.update({
      content: `**Done purchased ${tokenq} \n prefix : ${prefiq}** `,
      components : [new MessageActionRow().addComponents (
        new MessageButton()
        .setCustomId('kiq')
        .setLabel('تم الضغط')
        .setStyle('DANGER')
        .setDisabled(true)
      )]
    });
  }
});



///come
const come = require('./models/come.js');

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  if (interaction.customId === 'myModale') {
    // Get the data entered by the user
    const tokene = interaction.fields.getTextInputValue('tokene');
    const prefie = interaction.fields.getTextInputValue('prefie');

   come.findOne({id : interaction.guild.id} , async (data) => {
    if (!data) {
      come.create (
        {
          id : interaction.guild.id , 
          token : tokene , 
          prefix : prefie

        }
      )
    }
  })
    
   

    console.log(tokene, prefie);
    const tt = await logg.findOne({ id: interaction.guild.id });
    const channelMention = tt.channel;
    const channelId = channelMention.match(/\d+/)[0];
    const channel = await interaction.guild.channels.cache.get(channelId);
    const ttt = await loggg.findOne({id : interaction.guild.id})
    const channell = await interaction.guild.channels.cache.get(ttt.channel);
    const userr = interaction.user.username;
    await channell.send({content : `**Come bot has been bought by ${userr}**`})
    await channel.send({
      content: `**Done purchased Come bot ${tokene} \n prefix :- ${prefie} \n Id : ${myId} \n Purshased by : ${interaction.user}**`,
    });
    const user = interaction.user
    user.send({   content: `**Done purchased ${tokene} \n prefix : ${prefie}  \n برجاء الانتظار حتى يكون بوتك أونلاين ** ` })
    await interaction.update({
      content: `**Done purchased ${tokene} \n prefix : ${prefie} **`,
      components : [new MessageActionRow().addComponents (
        new MessageButton()
        .setCustomId('kie')
        .setLabel('تم الضغط')
        .setStyle('DANGER')
        .setDisabled(true)
      )]
    });
  }
});

///fora gav
const gav = require('./models/gav.js')
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;

  if(interaction.customId === 'myModalx') {
  // Get the data entered by the user
  const tokenx = interaction.fields.getTextInputValue('tokenx');
  const prefic = interaction.fields.getTextInputValue('prefic');

  gav.findOne({
    id: interaction.guild.id
  }, async (data) => {
    if (!data) {
      gav.create({
        id: interaction.guild.id,
        token: tokenx,
        prefix: prefic
      })


    }
  })

  console.log(tokenx, prefic)

  const ha = await line.findOne({
    id: interaction.guild.id
  })


  // const bot = new Client({
  //   intents: ['GUILD_MESSAGES', 'GUILDS'],
  //   prefix: prefix,
  // });

  // bot.on('ready', () => {
  //   console.log(`Logged in as ${bot.user.tag}`);
  // });
  


  // const tax = require('probot-taxs');
  // bot.on('messageCreate', async message => {
  //   if (message.content.startsWith('tax')) {
  //     const args = message.content.split(' ').slice('1').join(' ')
  //     let taxs = tax.tax(args, true)
  //     let taxbader = new MessageEmbed()
  //       .setTitle('the tax of probot')
  //       .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
  //       .addFields({ name: 'the tax of probot', value: `**${taxs.tax}**` })
  //       .addFields({ name: 'the tax with wasit', value: `**${taxs.wasit}**` })
  //       .setTimestamp();

  //     await message.reply({ embeds: [taxbader] });
  //   }
  // });

  // bot.login(token);
  const tt = await logg.findOne({ id: interaction.guild.id });
  const channelMention = tt.channel;
  const channelId = channelMention.match(/\d+/)[0];
  const channel = await interaction.guild.channels.cache.get(channelId);
  const ttt = await loggg.findOne({id : interaction.guild.id})
  const channell = await interaction.guild.channels.cache.get(ttt.channel);
  const userr = interaction.user.username;
  await channell.send({content : `**Giveaway bot bot has been bought by ${userr}**`})
  await channel.send({
    content: `**Done purchased Giveaway bot ${tokenx} \n prefix :- ${prefic} \n Id : ${myId} \n Purshased by : ${interaction.user}**`,
  });

  const user = interaction.user
    user.send({   content: `**Done purchased ${tokenx} \n prefix : ${prefic}   \n برجاء الانتظار حتى يكون بوتك أونلاين **` })
  await interaction.update({
    content: `**Done purchased ${tokenx} \n prefix : ${prefic}** `,
    components : [new MessageActionRow().addComponents (
      new MessageButton()
      .setCustomId('kix')
      .setLabel('تم الضغط')
      .setStyle('DANGER')
      .setDisabled(true)
    )]
  });


  }


});
/// foe mod

const mod = require('./models/mod.js')
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;

  if(interaction.customId === 'myModalllll') {
  // Get the data entered by the user
  const tokennnnn = interaction.fields.getTextInputValue('tokennnnn');
  const prefixxxxx = interaction.fields.getTextInputValue('prefixxxxx');

  mod.findOne({
    id: interaction.guild.id
  }, async (data) => {
    if (!data) {
      mod.create({
        id: interaction.guild.id,
        token: tokennnnn,
        prefix: prefixxxxx
      })


    }
  })

  console.log(tokennnnn, prefixxxxx)

  const ha = await mod.findOne({
    id: interaction.guild.id
  })


  // const bot = new Client({
  //   intents: ['GUILD_MESSAGES', 'GUILDS'],
  //   prefix: prefix,
  // });

  // bot.on('ready', () => {
  //   console.log(`Logged in as ${bot.user.tag}`);
  // });


  // const tax = require('probot-taxs');
  // bot.on('messageCreate', async message => {
  //   if (message.content.startsWith('tax')) {
  //     const args = message.content.split(' ').slice('1').join(' ')
  //     let taxs = tax.tax(args, true)
  //     let taxbader = new MessageEmbed()
  //       .setTitle('the tax of probot')
  //       .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
  //       .addFields({ name: 'the tax of probot', value: `**${taxs.tax}**` })
  //       .addFields({ name: 'the tax with wasit', value: `**${taxs.wasit}**` })
  //       .setTimestamp();

  //     await message.reply({ embeds: [taxbader] });
  //   }
  // });

  // bot.login(token);
  const tt = await logg.findOne({ id: interaction.guild.id });
  const channelMention = tt.channel;
  const channelId = channelMention.match(/\d+/)[0];
  const channel = await interaction.guild.channels.cache.get(channelId);
  const ttt = await loggg.findOne({id : interaction.guild.id})
  const channell = await interaction.guild.channels.cache.get(ttt.channel);
  const userr = interaction.user.username;
  await channell.send({content : `**Moderation bot bot has been bought by ${userr}**`})
  await channel.send({
    content: `**Done purchased Moderation bot ${tokennnnn} \n prefix :- ${prefixxxxx} \n Id : ${myId} \n Purshased by : ${interaction.user}**`,
  });
  const user = interaction.user
    user.send({     content: `**Done purchased ${tokennnnn} \n prefix : ${prefixxxxx}  \n برجاء الانتظار حتى يكون بوتك أونلاين  **` })
  await interaction.update({
    content: `**Done purchased ${tokennnnn} \n prefix : ${prefixxxxx}** `,
    components : [new MessageActionRow().addComponents (
      new MessageButton()
      .setCustomId('kiiiii')
      .setLabel('تم الضغط')
      .setStyle('DANGER')
      .setDisabled(true)
    )]
  });

  }


});

/// for giv
const giv = require('./models/gav.js')
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;

  if(interaction.customId === 'myModallllll') {
  // Get the data entered by the user
  const tokennnnnn = interaction.fields.getTextInputValue('tokennnnnn');
  const prefixxxxxx = interaction.fields.getTextInputValue('prefixxxxxx');

  giv.findOne({
    id: interaction.guild.id
  }, async (data) => {
    if (!data) {
      giv.create({
        id: interaction.guild.id,
        token: tokennnnnn,
        prefix: prefixxxxxx
      })


    }
  })

  console.log(tokennnnnn, prefixxxxxx)

  const ha = await giv.findOne({
    id: interaction.guild.id
  })


  // const bot = new Client({
  //   intents: ['GUILD_MESSAGES', 'GUILDS'],
  //   prefix: prefix,
  // });

  // bot.on('ready', () => {
  //   console.log(`Logged in as ${bot.user.tag}`);
  // });
 

  // const tax = require('probot-taxs');
  // bot.on('messageCreate', async message => {
  //   if (message.content.startsWith('tax')) {
  //     const args = message.content.split(' ').slice('1').join(' ')
  //     let taxs = tax.tax(args, true)
  //     let taxbader = new MessageEmbed()
  //       .setTitle('the tax of probot')
  //       .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
  //       .addFields({ name: 'the tax of probot', value: `**${taxs.tax}**` })
  //       .addFields({ name: 'the tax with wasit', value: `**${taxs.wasit}**` })
  //       .setTimestamp();

  //     await message.reply({ embeds: [taxbader] });
  //   }
  // });

  // bot.login(token);


 
  const tt = await logg.findOne({ id: interaction.guild.id });
  const channelMention = tt.channel;
  const channelId = channelMention.match(/\d+/)[0];
  const channel = await interaction.guild.channels.cache.get(channelId);
  const ttt = await loggg.findOne({id : interaction.guild.id})
  const channell = await interaction.guild.channels.cache.get(ttt.channel);
  const userr = interaction.user.username;
  await channell.send({content : `**Ticket bot has been bought by ${userr}**`})
  await channel.send({
    content: `**Done purchased Ticket bot ${tokennnnnn} \n prefix :- ${prefixxxxxx} \n Id : ${myId} \n Purshased by : ${interaction.user}**`,
  });
  const user = interaction.user
  user.send({     content: `**Done purchased ${tokennnnnn} \n prefix :- ${prefixxxxxx}  \n برجاء الانتظار حتى يكون بوتك أونلاين **` })
  await interaction.update({
    content: `**Done purchased ${tokennnnnn} \n prefix :- ${prefixxxxxx} **`,
    components : [new MessageActionRow().addComponents (
      new MessageButton()
      .setCustomId('kiiiiii')
      .setLabel('تم الضغط')
      .setStyle('DANGER')
      .setDisabled(true)
    )]
  });

  }


});

/// for sug
const sug = require('./models/suggest.js')
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;

  if(interaction.customId === 'myModallll') {
  // Get the data entered by the user
  const tokennnn = interaction.fields.getTextInputValue('tokennnn');
  const prefixxxx = interaction.fields.getTextInputValue('prefixxxx');

  sug.findOne({
    id: interaction.guild.id
  }, async (data) => {
    if (!data) {
      sug.create({
        id: interaction.guild.id,
        token: tokennnn,
        prefix: prefixxxx
      })


    }
  })

  console.log(tokennnn, prefixxxx)

  const ha = await sug.findOne({
    id: interaction.guild.id
  })


  // const bot = new Client({
  //   intents: ['GUILD_MESSAGES', 'GUILDS'],
  //   prefix: prefix,
  // });

  // bot.on('ready', () => {
  //   console.log(`Logged in as ${bot.user.tag}`);
  // });
  

  // const tax = require('probot-taxs');
  // bot.on('messageCreate', async message => {
  //   if (message.content.startsWith('tax')) {
  //     const args = message.content.split(' ').slice('1').join(' ')
  //     let taxs = tax.tax(args, true)
  //     let taxbader = new MessageEmbed()
  //       .setTitle('the tax of probot')
  //       .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
  //       .addFields({ name: 'the tax of probot', value: `**${taxs.tax}**` })
  //       .addFields({ name: 'the tax with wasit', value: `**${taxs.wasit}**` })
  //       .setTimestamp();

  //     await message.reply({ embeds: [taxbader] });
  //   }
  // });

  // bot.login(token);

  const tt = await logg.findOne({ id: interaction.guild.id });
  const channelMention = tt.channel;
  const channelId = channelMention.match(/\d+/)[0];
  const channel = await interaction.guild.channels.cache.get(channelId);
  const ttt = await loggg.findOne({id : interaction.guild.id})
  const channell = await interaction.guild.channels.cache.get(ttt.channel);
  const userr = interaction.user.username;
  await channell.send({content : `**Suggestion bot has been bought by ${userr}**`})
  await channel.send({
    content: `**Done purchased Suggestion bot ${tokennnn} \n prefix :- ${prefixxxx} \n Id : ${myId} \n Purshased by : ${interaction.user}**`,
  });
  const user = interaction.user
  user.send({   content: `**Done purchased ${tokennnn} \n prefix :- ${prefixxxx}  \n برجاء الانتظار حتى يكون بوتك أونلاين ** ` })
  await interaction.update({
    content: `**Done purchased ${tokennnn} \n prefix :- ${prefixxxx} **`,
    components : [new MessageActionRow().addComponents (
      new MessageButton()
      .setCustomId('kiiii')
      .setLabel('تم الضغط')
      .setStyle('DANGER')
      .setDisabled(true)
    )]
  });

  }


});

///// for close 

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;

  if(interaction.customId === 'close') {

    await interaction.channel.delete({timeout : 10000})
    await interaction.update({content : `**Done Will close after 10 seconds**`})

  }
})

const maker = require('./models/maker.js')
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;

  if(interaction.customId === 'myModal') {
  // Get the data entered by the user
  const token = interaction.fields.getTextInputValue('token');
  const prefix = interaction.fields.getTextInputValue('prefix');

  maker.findOne({
    id: interaction.guild.id
  }, async (data) => {
    if (!data) {
      maker.create({
        id: interaction.guild.id,
        token: token,
        prefix: prefix
      })


    }
  })

  console.log(token, prefix)

  const ha = await maker.findOne({
    id: interaction.guild.id
  })


  // const bot = new Client({
  //   intents: ['GUILD_MESSAGES', 'GUILDS'],
  //   prefix: prefix,
  // });

  // bot.on('ready', () => {
  //   console.log(`Logged in as ${bot.user.tag}`);
  // });
  


  // const tax = require('probot-taxs');
  // bot.on('messageCreate', async message => {
  //   if (message.content.startsWith('tax')) {
  //     const args = message.content.split(' ').slice('1').join(' ')
  //     let taxs = tax.tax(args, true)
  //     let taxbader = new MessageEmbed()
  //       .setTitle('the tax of probot')
  //       .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
  //       .addFields({ name: 'the tax of probot', value: `**${taxs.tax}**` })
  //       .addFields({ name: 'the tax with wasit', value: `**${taxs.wasit}**` })
  //       .setTimestamp();

  //     await message.reply({ embeds: [taxbader] });
  //   }
  // });

  // bot.login(token);


  const tt = await logg.findOne({ id: interaction.guild.id });
  const channelMention = tt.channel;
  const channelId = channelMention.match(/\d+/)[0];
  const channel = await interaction.guild.channels.cache.get(channelId);
  const ttt = await loggg.findOne({id : interaction.guild.id})
  const channell = await interaction.guild.channels.cache.get(ttt.channel);
  const userr = interaction.user.username;
  await channell.send({content : `**Tax bot has been bought by ${userr}**`})
  await channel.send({
    content: `**Done purchased Tax bot ${token} \n prefix :- ${prefix} \n Id : ${myId} \n Purshased by : ${interaction.user}**`,
  });
  const user = interaction.user
  user.send({     content: `**Done purchased ${token} \n prefix :- ${prefix}  \n برجاء الانتظار حتى يكون بوتك أونلاين **` })
  await interaction.update({
    content: `**Done purchased ${token} \n prefix :- ${prefix}** `,
    components : [new MessageActionRow().addComponents (
      new MessageButton()
      .setCustomId('ki')
      .setLabel('تم الضغط')
      .setStyle('DANGER')
      .setDisabled(true)
    )]
  });


  }


});

client.on('ready', () => {
  console.log('Logged in as', client.user.tag);

  maker.find({}, (err, docs) => {
    if (err) {
      console.error(err);
    } else {
      docs.forEach(config => {
        console.log('Config retrieved:', config);
        const botq = new Client({
          intents:  ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS" , "GUILD_PRESENCES" , "GUILD_BANS" , "GUILD_INVITES" , "GUILD_MESSAGE_REACTIONS" , "GUILD_MESSAGE_TYPING" , "DIRECT_MESSAGES" , "DIRECT_MESSAGE_REACTIONS" , "DIRECT_MESSAGE_TYPING"],
          prefix: config.prefix,
        });

        // Consolidate ready event listeners into a single function
        botq.on('ready', () => {
          console.log(`Bot ${botq.user.tag} is ready`);
const tax = require('probot-taxs')
          botq.on('messageCreate', async message => {
            if(message.content.startsWith(config.prefix +'tax')) {
              const args = message.content.split(' ').slice('1').join(' ')
              let taxs = tax.tax(args, true)
              const rea = new MessageButton()
              .setCustomId('hya')
              .setLabel('الترجمة للغة العربية')
              .setStyle('DANGER')
              .setEmoji('✅')
              const uay = new MessageActionRow()
              .addComponents(rea)
              let taxbader = new MessageEmbed()
                .setTitle('the tax of probot')
                .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                .addFields({ name: 'the tax of probot', value: `**${taxs.tax}**` })
                .addFields({ name: 'the tax with wasit', value: `**${taxs.wasit}**` })
                .setTimestamp();

              await message.reply({ embeds: [taxbader] , components : [uay] });
            }
          });
            
                      botq.on('interactionCreate', async interaction => {
                          if(!interaction.isButton()) return
                         if(interaction.customId === 'hya' ) {
                             await interaction.deferReply({ephemeral : true})
                             await interaction.editReply({content : `**أول رقم ده الضريبة بدون الوسيط \n تانى رقم ده الضريبة بالوسيط**`})
                             
                             
                         }
                      })
                             
              


          botq.on('messageCreate', (message) => {
            if (message.content.startsWith(config.prefix + 'discount')) {
              const args = message.content.slice(config.prefix.length).trim().split(/ +/);
              const price = parseFloat(args[1]);
              const discount = parseFloat(args[2]);
              if (isNaN(price) || isNaN(discount)) {
                message.reply('Invalid arguments. Usage: !discount <price> <discount>');
                return;
              }
              const discountedPrice = price * (1 - discount / 100);
              message.reply(`**The price after a ${discount}% discount is ${discountedPrice.toFixed(2)}.**`);
            }
          });

          botq.on('messageCreate', async message => {
            if (message.content.startsWith(config.prefix + `help`)) {
              const help = new MessageEmbed()
              .addFields(
                {
                  name : `${config.prefix}tax` ,
                  value : `**for knowing a tax for specific number**`
                }
              )
              .addFields(
                {
                  name : `${config.prefix}discount` ,
                  value : `**to know the number after discount for example :- -discount 20000 50%**`
                }
              )
              .setImage('https://www.babup.com/do.php?img=25460')

              await message.channel.send({embeds : [help]})
            }
          });
        });

        botq.login(config.token);
      });
    }
  });
});

  /// broad
 client.on('ready', async () => {
  
    console.log('Logged in as', client.user.tag);
  broad.find({}, (err, docs) => {
    if (err) {
      console.error(err);
    } else {
      docs.forEach(config => {
        const botw = new Client({
          intents:  ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS" , "GUILD_PRESENCES" , "GUILD_BANS" , "GUILD_INVITES" , "GUILD_MESSAGE_REACTIONS" , "GUILD_MESSAGE_TYPING" , "DIRECT_MESSAGES" , "DIRECT_MESSAGE_REACTIONS" , "DIRECT_MESSAGE_TYPING"],
          prefix: config.prefix,
          
        });
       const  prefix = config.prefix 
        botw.on('ready', () => {
          console.log(`Logged in as ${botw.user.tag}`);
        });
botw.on("messageCreate", async (message) => {
  if (message.content.startsWith(prefix + "bc")) {
    // Check for user permissions
    if (!message.member.permissions.has("ADMINISTRATOR")) {
      return message.reply({ content: `**You don't have permission to use this command**` });
    }

    // Get the broadcast message from the command
    let args = message.content.split(" ").slice(1).join(" ");

    // Check if a broadcast message was provided
    if (!args) {
      let noargs = new MessageEmbed()
        .setAuthor(
          message.author.username,
          message.author.displayAvatarURL({ dynamic: true })
        )
        .addField(`Error :x:`, `Please type your broadcast message!`)
        .setTimestamp()
        .setFooter(
          message.author.username,
          message.author.displayAvatarURL({ dynamic: true })
        );
      return message.channel.send({ embeds: [noargs] }); // Send the error message in an embed
    }

    // Broadcast the message to all online members
    message.guild.members.cache
      .filter((m) => m.presence && m.presence.status === "online" && !m.user.bot)
      .forEach(async (m) => {
        try {
          await m.send(args); // Send the message to the member
          console.log(`I could send to: ${m.user.tag} ✅`);
        } catch (error) {
          console.log(`I couldn't send to: ${m.user.tag} ❌ `, error);
        }
      });

    // Send a confirmation message in the channel
    let embed = new MessageEmbed()
      .setAuthor(
        message.author.username,
        message.author.displayAvatarURL({ dynamic: true })
      )
      .setDescription(
        `📬: Broadcast message sent to \`${
          message.guild.members.cache.filter(
            (m) => m.presence && m.presence.status === "online" && !m.user.bot
          ).size
        }\` members`
      )
      .setTimestamp()
      .setFooter(
        message.author.username,
        message.author.displayAvatarURL({ dynamic: true })
      );
    const confirmationMessage = await message.channel.send({
      content: `Sending the broadcast message to all online members...`,
    });
    if (confirmationMessage) {
      await confirmationMessage.edit({ embeds: [embed] }); // Send the confirmation message in an embed
    }
  }

  if (message.content.startsWith(prefix + "obc")) {
    // Check for user permissions
    if (!message.member.permissions.has("ADMINISTRATOR")) {
      return message.reply({ content: `**You don't have permission to use this command**` });
    }

    // Get the broadcast message from the command
    let args = message.content.split(" ").slice(1).join(" ");

    // Check if a broadcast message was provided
    if (!args) {
      let noargs = new MessageEmbed()
        .setAuthor(
          message.author.username,
          message.author.displayAvatarURL({ dynamic: true })
        )
        .addField(`Error :x:`, `Please type your broadcast message!`)
        .setTimestamp()
        .setFooter(
          message.author.username,
          message.author.displayAvatarURL({ dynamic: true })
        );
      return message.channel.send({ embeds: [noargs] }); // Send the error message in an embed
    }

    // Broadcast the message to all offline members
    message.guild.members.cache
      .filter((m) => m.presence && m.presence.status !== "online" && !m.user.bot)
      .forEach(async (m) => {
        try {
          await m.send(args); // Send the message to the member
          console.log(`I could send to: ${m.user.tag} ✅`);
        } catch (error) {
          console.log(`I couldn't send to: ${m.user.tag} ❌ `, error);
        }
      });

    // Send a confirmation message in the channel
    let embed = new MessageEmbed()
      .setAuthor(
        message.author.username,
        message.author.displayAvatarURL({ dynamic: true })
      )
      .setDescription(
        `📬: Broadcast message sent to \`${
          message.guild.members.cache.filter(
            (m) => m.presence && m.presence.status !== "online" && !m.user.bot
          ).size
        }\` members`
      )
      .setTimestamp()
      .setFooter(
        message.author.username,
        message.author.displayAvatarURL({ dynamic: true })
      );
    const confirmationMessage = await message.channel.send({
      content: `Sending the broadcast message to all offline members...`,
    });
    if (confirmationMessage) {
      await confirmationMessage.edit({ embeds: [embed] }); // Send the confirmation message in an embed
    }
  }
});
        botw.on('messageCreate', async message => {
          if (message.content.startsWith(prefix + `help`)) {
            const help = new MessageEmbed()
            .addFields(
              {
                name : `${prefix}bc` ,
                value : `**for broadcasting all members in server for ex -bc <message>**`
              }
            )
            .addFields(
              {
                name : `${prefix}obc` ,
                value : `**for broadcasting only online members for ex -obc <message>**`
              }
            )
            .setImage('https://www.babup.com/do.php?img=25461')

        
            await message.channel.send({embeds : [help]})
          
          }
        })

        botw.login(config.token);
      });
    }

  });

  })
  ///


  
  /// come

client.on('ready', () => {
  console.log('Logged in as', client.user.tag);
  come.find({}, (err, docs) => {
    if (err) {
      console.error(err);
    } else {
      docs.forEach(config => {
        const bote = new Client({
          intents:  ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS" , "GUILD_PRESENCES" , "GUILD_BANS" , "GUILD_INVITES" , "GUILD_MESSAGE_REACTIONS" , "GUILD_MESSAGE_TYPING" , "DIRECT_MESSAGES" , "DIRECT_MESSAGE_REACTIONS" , "DIRECT_MESSAGE_TYPING"],
          prefix: config.prefix,
          
        });
       const  prefix = config.prefix 
        bote.on('ready', async () => {
         
          console.log(`Logged in as ${bote.user.tag}`);
        });

      
       
        bote.on('messageCreate', async message => {
          if (message.content.startsWith(prefix + 'come')) {
            if (!message.member.permissions.has('ADMINISTRATION')) {
              message.reply('You do not have permission to use this command.');
              return;
            }
            const args = message.mentions.members.first();
            if (!args) {
              return message.reply({ content: '**Please mention a member first**' });
            }
            if (args.user.bot) {
              return message.reply({ content: '**Please mention a valid non-bot member.**' });
            }
            const channel = message.channel;
            args.send({ content: `**${args}, تعالى من فضلك لروم ${channel} بسرعة**` });
            await message.channel.send({ content: '**Done sent to this member in their DM successfully ✅**' });
          }
        });
        bote.on('messageCreate', async message => {
          if (message.content.startsWith(prefix + `help`)) {
            const help = new MessageEmbed()
            .addFields(
              {
                name : `**${prefix}come**` ,
                value : `**To call someone to a channel**`
              }
            )
            .setImage('https://www.babup.com/do.php?img=25462')

        
            await message.channel.send({embeds : [help]})
          
          }
        })
        bote.login(config.token);
      });
    }

  });
  say.find({}, (err, docs) => {
    if (err) {
      console.error(err);
    } else {
      docs.forEach(config => {
        const botr = new Client({
          intents:  ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS" , "GUILD_PRESENCES" , "GUILD_BANS" , "GUILD_INVITES" , "GUILD_MESSAGE_REACTIONS" , "GUILD_MESSAGE_TYPING" , "DIRECT_MESSAGES" , "DIRECT_MESSAGE_REACTIONS" , "DIRECT_MESSAGE_TYPING"],
          prefix: config.prefix,
          
        });
       const  prefix = config.prefix 
        botr.on('ready', async () => {
          await sayy(botr);
          console.log(`Logged in as ${botr.user.tag}`);
        });
          

      botr.on('messageCreate', async message => {
          if (message.content.startsWith(prefix + `help`)) {
            const helpp = new MessageEmbed()
            .addFields(
              {
                name : `**/say**` ,
                value : `**To say with embed or without embed Slash command**`
              }
            )
            .setImage('https://www.babup.com/do.php?img=25463')

        
            await message.channel.send({embeds : [helpp]})
          
          }
        })
       
botr.on('interactionCreate' , async interaction => {
  if(!interaction.isCommand())return 
  if(interaction.commandName=== 'say') {
    const embed = interaction.options.getString('with-embed')
    const embedd = interaction.options.getString('without-embed')

    if (embed) {
      await interaction.deferReply({ephemeral : true})
      await interaction.editReply({content : `Done created`})
      await interaction.channel.send({embeds : [new MessageEmbed().setDescription(`**${embed}**`).setThumbnail(interaction.guild.iconURL())]})
    }

    if(embedd) {
      await interaction.deferReply({ephemeral : true})
      await interaction.editReply({content : `Done created`})

      await interaction.channel.send({content : `**${embedd}**`})
    }

    if(!embed && !embedd) {
      await interaction.deferReply({ephemeral : true})
      await interaction.editReply({content : `**please choose at least embed or without embed**`})

    }
  }
} )


        botr.login(config.token);
      });
    }

  });

})
  //// for givaway
  client.on('ready', () => {
    console.log('Logged in as', client.user.tag);
  giv.find({}, (err, docs) => {
    if (err) {
      console.error(err);
    } else {
      docs.forEach(config => {
        const bott = new Client({
          intents:  ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS" , "GUILD_PRESENCES" , "GUILD_BANS" , "GUILD_INVITES" , "GUILD_MESSAGE_REACTIONS" , "GUILD_MESSAGE_TYPING" , "DIRECT_MESSAGES" , "DIRECT_MESSAGE_REACTIONS" , "DIRECT_MESSAGE_TYPING"],
          prefix: config.prefix,
          
        });
const prefix = config.prefix 
        bott.on('ready', () => {
          console.log(`Logged in as ${bott.user.tag}`);
        });
const mongo = require('mongodb').MongoClient;

const mongoUrl = 'mongodb+srv://Ahmed:12345@ahmed.f1uxuex.mongodb.net/data';
const dbName = 'giveaways';
const collectionName = 'participants';

let giveawayActive = false;
let giveawayMessage;
let giveawayEndTime;

bott.on('messageCreate', async (message) => {
if (message.author.bot) return;

if (message.content.startsWith(prefix + 'gstart')) {
if (!message.member.permissions.has('ADMINISTRATION')) {
message.reply('You do not have permission to use this command.');
return;
}


const args = message.content.slice('!gstart'.length).trim().split(/ +/g);
const duration = parseInt(args[0]);
const unit = args[1];
const numberOfWinners = parseInt(args[2]);
const prize = args.slice(3).join(' ');

if (isNaN(duration) || isNaN(numberOfWinners) || !prize || !['days', 'minutes', 'seconds' , 'hours' , 'years'].includes(unit)) {
  message.channel.send('Invalid command syntax.');
  return;
}

let durationInMilliseconds;
if (unit === 'years') {
  durationInMilliseconds = duration * 365 * 24 * 60 * 60 * 1000;
} else if (unit === 'days') {
  durationInMilliseconds = duration * 24 * 60 * 60 * 1000;
} else if (unit === 'hours') {
  durationInMilliseconds = duration * 60 * 60 * 1000;
} else if (unit === 'minutes') {
  durationInMilliseconds = duration * 60 * 1000;
} else if (unit === 'seconds') {
  durationInMilliseconds = duration * 1000;
}

if (!durationInMilliseconds) {
  message.channel.send('Invalid command syntax.');
  return;
}

const embed = new MessageEmbed()
  .setTitle('🎉 Giveaway Started 🎉')
  .setDescription(`Click the button below to enter!\nTime remaining: ${duration} ${unit}\nNumber of winners: ${numberOfWinners}\nPrize: **${prize}**`)
  .setColor('BLUE')
  .setFooter(`Hosted by ${message.author.tag}`)
.setImage('https://www.babup.com/do.php?img=25478')

const row = new MessageActionRow().addComponents(
  new MessageButton()
    .setCustomId('giveaway')
    .setLabel('Enter Giveaway')
    .setStyle('PRIMARY')
    .setEmoji('🎉')
);

giveawayMessage = await message.channel.send({ embeds: [embed], components: [row] });
 
giveawayEndTime = Date.now() + durationInMilliseconds;
giveawayActive = true;

const dbClient = await mongo.connect(mongoUrl);
const db = dbClient.db(dbName);
const collection = db.collection(collectionName);
await collection.deleteMany({});
dbClient.close();

setTimeout(async () => {
  giveawayActive = false;

  const dbClient = await mongo.connect(mongoUrl);
  const db = dbClient.db(dbName);
  const collection = db.collection(collectionName);
  const participants = await collection.find({ reacted: true }).toArray();
  const participantsArray = participants.map((participant) => participant.userId);

  if (participantsArray.length < numberOfWinners) {
    message.channel.send('Not enough participants to select a winner.');
    return;
  }

  const winners = [];
  while (winners.length < numberOfWinners) {
    const randomIndex = Math.floor(Math.random() * participantsArray.length);
    const participant = participantsArray[randomIndex];
    if (!winners.includes(participant)) {
      winners.push(participant);
    }
  }

  const winnerMentions = winners.map((winnerId) => `<@${winnerId}>`).join(', ');
  const winnerEmbed = new MessageEmbed()
    .setTitle('🎉 Giveaway ended')
    .setDescription(`🥳 **Congratulations ${winnerMentions}! You won ${prize}!**`)
    .setColor('GREEN')
    .setFooter(`Hosted by ${message.author.tag}`);
  await message.channel.send({ embeds: [winnerEmbed] });
  await message.channel.send({content : `🥳 **Congratulations ${winnerMentions}! You won ${prize}!**`})

  const dbClient2 = await mongo.connect(mongoUrl);
  const db2 = dbClient2.db(dbName);
  const collection2 = db2.collection(collectionName);
  participants.forEach(async (participant) => {
    await collection2.updateOne({ userId: participant.userId }, { $set: { reacted: false } });
  });
  dbClient2.close();
}, durationInMilliseconds);
}
});

bott.on('interactionCreate', async (interaction) => {
if (!interaction.isButton()) return;
if (!giveawayActive) return;
if (interaction.message.id !== giveawayMessage.id || interaction.customId !== 'giveaway') return;

const dbClient = await mongo.connect(mongoUrl);
const db = dbClient.db(dbName);
const collection = db.collection(collectionName);
const participant = await collection.findOne({ userId: interaction.user.id });
if (participant && participant.reacted) {
await interaction.reply({ content: 'You have already entered the giveaway!', ephemeral: true });
dbClient.close();
return;
}

await collection.updateOne({ userId: interaction.user.id }, { $set: { reacted: true } }, { upsert: true });
await interaction.deferReply({ fetchReply : true, ephemeral: true });
await interaction.editReply({ content: 'You have been entered into the giveaway!' });
dbClient.close();
});
        bott.on('messageCreate', async message => {
          if (message.content.startsWith(prefix + `help`)) {
            const help = new MessageEmbed()
            .addFields(
              {
                name : `${prefix}gstart` ,
                value : `**To start a giveaway for example :-  ${prefix}gstart 2 days 1 $50 gift card \n you can use minutes or seconds instead of days => ${prefix}gstart <duration> <unit> <number of winners> <prize>
**`
              }
            )
            .setImage('https://www.babup.com/do.php?img=25465')
 
        
            await message.channel.send({embeds : [help]})
          
          }
        })
        bott.login(config.token);
      });
    }

  });
  })

///
client.on('ready', () => {
  console.log('Logged in as', client.user.tag);
  oc.find({}, (err, docs) => {
    if (err) {
      console.error(err);
    } else {
      docs.forEach(config => {
        const boty = new Client({
          intents:  ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS" , "GUILD_PRESENCES" , "GUILD_BANS" , "GUILD_INVITES" , "GUILD_MESSAGE_REACTIONS" , "GUILD_MESSAGE_TYPING" , "DIRECT_MESSAGES" , "DIRECT_MESSAGE_REACTIONS" , "DIRECT_MESSAGE_TYPING"],
          prefix: config.prefix,
          
        });
     
        boty.on('ready', () => {
          console.log(`Logged in as ${boty.user.tag}`);
        });
      
       

// Define the prefix for commands
const prefix = config.prefix ;

// Define the ready event handler
client.on('ready', async () => {
  console.log(`Logged in as ${client.user.tag}`);

  // Load the current configuration from the config file
  
  // Load the current configuration from the config file
  const config = JSON.parse(fs.readFileSync('./config.json'));

  // Get the hide time and show time from the config file
  const hideTime = new Date(`1970-01-01T${config.hideTime}:00.000Z`);
  const showTime = new Date(`1970-01-01T${config.showTime}:00.000Z`);

  // Schedule the first hide and show events
  scheduleHideChannels(config.hiddenChannels, hideTime, client);
  scheduleShowChannels(config.hiddenChannels, showTime, client);
});
// Define the addchannels command


// Define the showchannels command



const Channel = require('./models/channels');

// Define the addchannels command
boty.on('messageCreate', async (message) => {
  if (message.content.startsWith(prefix + `addchannels`)) {
    if (!message.member.permissions.has('ADMINISTRATION')) {
      message.reply('You do not have permission to use this command.');
      return;
    }
    // Get the list of channels to add
    const channelsToAdd = message.mentions.channels;

    // Add the channels to the MongoDB database
    const promises = channelsToAdd.map(async (channel) => {
      const newChannel = new Channel({
        channelId: channel.id,
        guildId: channel.guild.id,
        userId: message.author.id,
      });
      await newChannel.save();
    });
    await Promise.all(promises);

    message.reply(`**${channelsToAdd.size} تم اضافة الرومات بنجاح لقاعدة البيانات.**`);
  }
});
          
boty.on('messageCreate', async (message) => {
      if (message.content.startsWith(prefix + "removechannel")) {
    if (!message.member.permissions.has('ADMINISTRATION')) {
      message.reply('You do not have permission to use this command.');
      return;
    }
    let channel = message.mentions.channels.first();
    if (!channel || channel.type !== "GUILD_TEXT") return message.channel.send(`There is not a text channel`);
    let tara = await Channel.findOne({ channelID: channel.id });
    if (!tara) return message.channel.send(`not channel added yet`);
    await Channel.findOneAndDelete({ channelID: channel.id });
    message.channel.send(`Done removed this channel from database`);
  }
});
// Define the hidechannels command
boty.on('messageCreate', async (message) => {
  if (message.content.startsWith(prefix + `hidechannels`)) {
    if (!message.member.permissions.has('ADMINISTRATION')) {
      message.reply('You do not have permission to use this command.');
      return;
    }
    // Find the user's hidden channels in the database
    const hiddenChannels = await Channel.find({ userId: message.author.id });

    // Hide the hidden channels
    hideChannels(hiddenChannels.map(channel => channel.channelId), boty);

    message.reply(`** تم اخفاء الرومات التى تم اضافتها بنجاح ${hiddenChannels.length} **.`);
  }
});

boty.on('messageCreate', async (message) => {
  if (message.content.startsWith(prefix + `showchannels`)) {
    if (!message.member.permissions.has('ADMINISTRATION')) {
      message.reply('You do not have permission to use this command.');
      return;
    }
    // Find the user's hidden channels in the database
    const hiddenChannels = await Channel.find({ userId: message.author.id });

    // Hide the hidden channels
    showChannels(hiddenChannels.map(channel => channel.channelId), boty);

    message.reply(`** تم اطهار الرومات التى تم اضافتها بنجاح ${hiddenChannels.length} **.`);
  }
});
boty.on('messageCreate', (message) => {
  if (message.content.startsWith(prefix + `resetconfig`)) {
    if (!message.member.permissions.has('ADMINISTRATION')) {
      message.reply('You do not have permission to use this command.');
      return;
    }
    // Delete the user's configuration file
    try {
      fs.unlinkSync(`./config_${message.author.id}.json`);
      message.reply('**تم ازالة جميع الرومات التى تم اضافتها.**');
    } catch (err) {
      // If the file doesn't exist, send an error message
      if (err.code === 'ENOENT') {
        message.reply(`**ليس لديك اي بيانات في الاصل.**`);
      } else {
        console.error(err);
        message.reply(`**حدث خطأ اثناء محاولة ازالة البيانات.**`);
      }
    }
  }
});
boty.on('messageCreate', async message => {
  if (message.content.startsWith(prefix + `help`)) {
    const help = new MessageEmbed()
    .addFields(
      {
        name : `${prefix}addchannels` ,
        value : `**To add channels that show it or hide them**`
      }
    )
        .addFields(
      {
        name : `${prefix}removechannel` ,
        value : `**To remove channel from database that you are added it**`
      }
    )
    .addFields(
      {
        name : `${prefix}showchannels` ,
        value : `**To show channels**`
      }
    )
    .addFields(
      {
        name : `${prefix}hidechannels` ,
        value : `**To hide channels**`
      }
    )
    .setImage('https://www.babup.com/do.php?img=25466')
    
  

    await message.channel.send({embeds : [help]})
  
  }
})
      
// Helper function to hide the channels
async function hideChannels(channelIds, bot) {
  const channels = await Promise.all(channelIds.map((channelId) => bot.channels.fetch(channelId)));
  channels.forEach((channel) => {
    if (channel) {
      channel.permissionOverwrites.edit(channel.guild.roles.everyone, { VIEW_CHANNEL: false });
    }
  });
}

// Helper function to show the channels
async function showChannels(channelIds, bot) {
  const channels = await Promise.all(channelIds.map((channelId) => bot.channels.fetch(channelId)));
  channels.forEach((channel) => {
    if (channel) {
      channel.permissionOverwrites.edit(channel.guild.roles.everyone, { VIEW_CHANNEL: true });
    }
  });
}

// Helper function to schedule the next hide event
function scheduleHideChannels(channelIds, hideTime, bot) {
  const currentTime = new Date();
  let nextHideTime = hideTime;
  while (nextHideTime <= currentTime) {
    nextHideTime = new Date(nextHideTime.getTime() + 24 * 60 * 60 * 1000);
  }
  setTimeout(() => {
    hideChannels(channelIds, bot);
    scheduleHideChannels(channelIds, hideTime, bot);
  }, nextHideTime - currentTime);
}

// Helper function to schedule the next show event
function scheduleShowChannels(channelIds, showTime, bot) {
  const currentTime = new Date();
  let nextShowTime = showTime;
  while (nextShowTime <= currentTime) {
    nextShowTime = new Date(nextShowTime.getTime() + 24 * 60 * 60 * 1000);
  }
  setTimeout(() => {
    showChannels(channelIds, bot);
    scheduleShowChannels(channelIds, showTime, bot);
  }, nextShowTime - currentTime);
}
        
  
        boty.login(config.token);
      });
    }
  });
})
///// 
client.on('ready', () => {
  console.log('Logged in as', client.user.tag);
const lineo = require('./models/line.js')

  lineo.find({}, (err, docs) => {
    if (err) {
      console.error(err);
    } else {
      docs.forEach(config => {
        const botu = new Client({
          intents:  ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS" , "GUILD_PRESENCES" , "GUILD_BANS" , "GUILD_INVITES" , "GUILD_MESSAGE_REACTIONS" , "GUILD_MESSAGE_TYPING" , "DIRECT_MESSAGES" , "DIRECT_MESSAGE_REACTIONS" , "DIRECT_MESSAGE_TYPING"],
          prefix: config.prefix,
        });

        botu.on('ready', () => {
          console.log(`Logged in as ${botu.user.tag}`);
        });
      const prefix = config.prefix
      const autoLineModel = require("./models/auto_line")
      const LineModel = require("./models/line2")
    
      botu.on("messageCreate", async message => {
        if (message.author.bot) return; // Ignore messages from bots
        if (message.channel.type !== "GUILD_TEXT") return; // Only process messages in text channels
        if (!message.guild) return; // Ignore messages outside of guilds
        // if (!message.member.roles.cache.has(commandsAccessRole)) return; // Check if the user has the necessary role
      
        if (message.content.startsWith(prefix + "add-channel")) {
          if (!message.member.permissions.has('ADMINISTRATION')) {
            message.reply('You do not have permission to use this command.');
            return;
          }
          let channel = message.mentions.channels.first();
          if (!channel || channel.type !== "GUILD_TEXT") return message.channel.send(`**this is not guild text channel**`);
          let autoLineData = await autoLineModel.findOne({ channelID: channel.id });
          if (autoLineData) return message.channel.send(`Done added the channel`);
          let newAutoLineData = new autoLineModel({
            channelID: channel.id,
          });
          await newAutoLineData.save();
          message.channel.send(`**Done added the channel**`).catch(() => {});
        }
      });

      botu.on("messageCreate", async message => {
        if (message.author.bot) return; // Ignore messages from bots
        if (message.channel.type !== "GUILD_TEXT") return; // Only process messages in text channels
        if (!message.guild) return; // Ignore messages outside of guilds
        // if (!message.member.roles.cache.has(commandsAccessRole)) return; // Check if the user has the necessary role
      
        if (message.content.startsWith(prefix + "add-line")) {
          if (!message.member.permissions.has('ADMINISTRATION')) {
            message.reply('You do not have permission to use this command.');
            return;
          }
          let line = message.content.slice((prefix + "add-line").length).trim();
          if (!line.startsWith("https://")) return message.channel.send(`**this is not invalid line**`);
          let lineData = await LineModel.findOne({id : message.guild.id});
          if (lineData) return message.channel.send(`Done added`);
          LineModel.findOne({id : message.guild.id} , async (data) => {
              if (!data) {
                  LineModel.create(
                  {
                      id : message.guild.id , 
                      Line : line
                  })
              }
          })
            
            const jvj = await LineModel.findOne({id  : message.guild.id})
          message.channel.send(`Done added line `).catch(() => {});
        }
      });
      botu.on('messageCreate', async (message) => {
        if (!message.content.startsWith(prefix) || message.author.bot) return;
        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const command = args.shift().toLowerCase();
        if (command === "remove-channel") {
          if (!message.member.permissions.has('ADMINISTRATION')) {
            message.reply('You do not have permission to use this command.');
            return;
          }
          if (!message.guild) return message.reply(`**that not a guild**`);
          // if (!message.member.roles.cache.has(commandsAccessRole)) return message.reply(`${Emoji.Warn} ${Reply.noPerms}`);
          const channel = message.mentions.channels.first();
          if (!channel || channel.type !== "GUILD_TEXT") return message.reply({content : `this is invalid channel`});
          const autoLineData = await autoLineModel.findOne({ channelID: channel.id });
          if (!autoLineData) return message.reply(`there is no data line`);
          await autoLineData.delete();
          await message.reply(`Done removed`).catch(() => {});
        }
      });

      botu.on("messageCreate" , async message => {
        if (message.content.startsWith("خط")) {
          if (!message.member.permissions.has('ADMINISTRATION')) {
            message.reply('You do not have permission to use this command.');
            return;
          }
            if (!message.guild) return message.reply({ content: `this is not a guild that use in it the line`});
            // if (!message.member.roles.cache.has(commandsAccessRole)) return message.reply({ content: `${Emoji.Warn} ${Reply.noPerms}`});
            let lineData = await LineModel.findOne({id : message.guild.id});
            if (!lineData) return message.reply({ content: `Not line added Yet`});
            message.delete();
            message.channel.send({files: [lineData.Line]}).catch(() => {});
        }
    });

    botu.on("messageCreate" , async(message) => {
      if (message.author.bot) return;
      if (message.channel.type === "DM") return;
      let autoLineData = await autoLineModel.findOne({ channelID: message.channel.id });
      if (!autoLineData) return;
      let lineData = await LineModel.findOne({id : message.guild.id});
      if (!lineData) return;
      message.channel.send({files: [lineData.Line]});
  });
  

  botu.on("messageCreate", async message => {
    if (message.author.bot) return; // Ignore messages from bots
    if (message.channel.type !== "GUILD_TEXT") return; // Only process messages in text channels
    if (!message.guild) return; // Ignore messages outside of guilds
    // if (!message.member.roles.cache.has(commandsAccessRole)) return; // Check if the user has the necessary role
  
    if (message.content.startsWith(prefix + "remove-line")) {
      if (!message.member.permissions.has('ADMINISTRATION')) {
        message.reply('You do not have permission to use this command.');
        return;
      }
      let line = message.content.slice((prefix + "remove-line").length).trim();
      let lineData = await LineModel.findOne({ id : message.guild.id , Line : line});
      if (!lineData) return message.channel.send(`There is no line in database`);
      await lineData.delete();
      message.channel.send(`Done removed the line`).catch(() => {});
    }
  });

  
  botu.on('messageCreate', async message => {
    if (message.content.startsWith(prefix + `help`)) {
      const help = new MessageEmbed()
      .addFields(
        {
          name : `${prefix}add-channel` ,
          value : `**To add channels that sent to them line**`
        }
      )
      .addFields(
        {
          name : `${prefix}add-line` ,
          value : `**To add line**`
        }
      )
      .addFields(
        {
          name : `${prefix}remove-line` ,
          value : `**To remove line**`
        }
      )
      .addFields(
        {
          name : `${prefix}remove-channel` ,
          value : `**To remove channel from sent to i line**`
        }
      )
      .addFields(
        {
          name : `خط` ,
          value : `**لكى يرسل خط**`
        }
      )
      .setImage('https://www.babup.com/do.php?img=25467')


      await message.channel.send({embeds : [help]})
    
    }
  })


//       bot.on('messageCreate', async (message) => {

//         const fad = await len.findOne({id : message.guild.id})
//         const attachment = new MessageAttachment(config.line);
// const chann = message.guild.channels.cache.get(fad.channels)

// if(chann) {
//   message.channel.send()
// }

//       })
        



        botu.login(config.token);
      });
    }

  });
})
  //

  client.on('ready', () => {
    console.log('Logged in as', client.user.tag);
  sug.find({}, (err, docs) => {
    if (err) {
      console.error(err);
    } else {
      docs.forEach(config => {
        const boti = new Client({
          intents:  ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS" , "GUILD_PRESENCES" , "GUILD_BANS" , "GUILD_INVITES" , "GUILD_MESSAGE_REACTIONS" , "GUILD_MESSAGE_TYPING" , "DIRECT_MESSAGES" , "DIRECT_MESSAGE_REACTIONS" , "DIRECT_MESSAGE_TYPING"],
          prefix: config.prefix,
        });

        boti.on('ready', () => {
          console.log(`Logged in as ${boti.user.tag}`);
        });
        const prefix = config.prefix;
        // const sugCommand = 'sug';

        // // Keep track of the last suggestion sent to each channel
        // const lastSuggestions = new Map();
        
        // // Emojis for the reactions
        // const checkmarkEmoji = '✅';
        // const xEmoji = '❌';
        
        // // Load the configuration object from file
        // const configg = JSON.parse(fs.readFileSync('./sug.json'));
        
        // bot.on('ready', () => {
        //   console.log(`Logged in as ${bot.user.tag}!`);
        // });
        
        // bot.on('messageCreate', async message => {
        //   if (message.content === `${prefix}setsuggestionschannel`) {
        //     const args = message.content.split(' ').slice(1);
        
        //     // Update the suggestions channel ID in the configuration object
        //     const channelId = args[0].replace(/<|#|>/g, '');
        //     configg.suggestionsChannel = channelId;
        //     fs.writeFileSync('./sug.json', JSON.stringify(configg));
        
        //     message.channel.send(`Suggestions channel set to ${channelId}.`);
        //   }
        // });
        
        // bot.on('messageCreate', async message => {
        //   if (!message.content.startsWith(prefix) || message.author.bot) return;
        //   const configg = JSON.parse(fs.readFileSync('./sug.json'));
        //   const args = message.content.slice(prefix.length).trim().split(/ +/);
        //   const command = args.shift().toLowerCase();
        
        //   if (command === sugCommand) {
        //     // Send the suggestion to the configured channel
        //     const suggestion = args.join(' ');
        
        //     // Check if the suggestion is empty
        //     if (!suggestion) {
        //       message.channel.send('Please provide a suggestion.');
        //       return;
        //     }
        
        //     const channel = bot.channels.cache.get(configg.suggestionsChannel);
        
        //     // Check if the channel exists
        //     if (!channel) {
        //       console.log(`Could not find suggestions channel with ID ${configg.suggestionsChannel}.`);
        //       return;
        //     }
        
        //     const suggestionMessage = await channel.send(`New suggestion from ${message.author}: ${suggestion}`);
        //     suggestionMessage.react(checkmarkEmoji);
        //     suggestionMessage.react(xEmoji);
        //     message.channel.send('Thank you for your suggestion!');
        //   }
        // });
        // bot.on('messageCreate', (message) => {
        //   if (message.content === `${prefix}resetconfigsug`) {
        //     // Load the configuration from line.json
        //     const config = JSON.parse(fs.readFileSync('./sug.json'));
        
        //     // Reset the channels and line properties
        //     config.suggestionsChannel = "";
         
        
        //     // Write the updated configuration back to line.json
        //     fs.writeFileSync('./sug.json', JSON.stringify(config, null, 2));
        
        //     message.reply('**تم ازالة جميع الرومات التى تم اضافتها.**');
        //   }
        // });
        const suggestModel = require("./models/suggest")
        boti.on("messageCreate", async message => {
          if (message.author.bot) return; // Ignore messages from bots
          if (message.channel.type !== "GUILD_TEXT") return; // Only process messages in text channels
          if (!message.guild) return; // Ignore messages outside of guilds
          // if (!message.member.roles.cache.has(commandsAccessRole)) return; // Check if the user has the necessary role
        
          if (message.content.startsWith(prefix + "set-sug-channel")) {
            if (!message.member.permissions.has('ADMINISTRATION')) {
              message.reply('You do not have permission to use this command.');
              return;
            }
            let channel = message.mentions.channels.first();
            if (!channel || channel.type !== "GUILD_TEXT") return message.channel.send(`**this is not a valid channel**`);
            let suggestData = await suggestModel.findOne({ channelID: channel.id });
            if (suggestData) return message.channel.send(`Done added channel`);
            let newData = new suggestModel({
              channelID: channel.id,
            });
            await newData.save();
            message.channel.send(`Done added channel`);
          }
        });


        boti.on("messageCreate" , async(message) => {
    if (message.author.bot) return;
    if (message.channel.type === "DM") return;
    let suggestData = await suggestModel.findOne({ channelID: message.channel.id });
    if (!suggestData) return;
    let lineData = await LineModel.findOne();
    if (!lineData) return;
     message.channel.send({files: [lineData.Line]});
    message.delete();
    let embed = new MessageEmbed()
    .setAuthor({
        name: message.author.tag,
        iconURL: message.author.displayAvatarURL()
    })
    .setDescription(`${message.content}`)
    .setFooter({
        text: message.guild.name,
        iconURL: message.guild.iconURL()
    })
    .setTimestamp();
    await message.channel.send({embeds: [embed]}).then(async(msg) => {
        await msg.channel.send({files: [lineData.Line]});
        await msg.react("✅");
        await msg.react("❌");
    });
});


boti.on("messageCreate", async message => {
  if (message.author.bot) return; // Ignore messages from bots
  if (message.channel.type !== "GUILD_TEXT") return; // Only process messages in text channels
  if (!message.guild) return; // Ignore messages outside of guilds
  // if (!message.member.roles.cache.has(commandsAccessRole)) return; // Check if the user has the necessary role

  if (message.content.startsWith(prefix + "remove-sug-channel")) {
    if (!message.member.permissions.has('ADMINISTRATION')) {
      message.reply('You do not have permission to use this command.');
      return;
    }
    let channel = message.mentions.channels.first();
    if (!channel || channel.type !== "GUILD_TEXT") return message.channel.send(`There is not a text channel`);
    let suggestData = await suggestModel.findOne({ channelID: channel.id });
    if (!suggestData) return message.channel.send(`not channel added yet`);
    await suggestModel.findOneAndDelete({ channelID: channel.id });
    message.channel.send(`Done removed this channel from database`);
  }
});

boti.on('messageCreate', async message => {
  if (message.content.startsWith(prefix + `help`)) {
    const help = new MessageEmbed()
    .addFields(
      {
        name : `${prefix}set-sug-channel` ,
        value : `**To set suggestion channel**`
      }
    )
    .addFields(
      {
        name : `${prefix}remove-sug-channel` ,
        value : `**To ban member {by} his id**`
      }
    )
    .setImage('https://www.babup.com/do.php?img=25468')
 

    await message.channel.send({embeds : [help]})
  
  }
})

        boti.login(config.token);
      });
    }

  });
  })



  client.on('ready', () => {
    console.log('Logged in as', client.user.tag);
  mod.find({}, (err, docs) => {
    if (err) {
      console.error(err);
    } else {
      docs.forEach(config => {
        const boto = new Client({
          intents:  ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS" , "GUILD_PRESENCES" , "GUILD_BANS" , "GUILD_INVITES" , "GUILD_MESSAGE_REACTIONS" , "GUILD_MESSAGE_TYPING" , "DIRECT_MESSAGES" , "DIRECT_MESSAGE_REACTIONS" , "DIRECT_MESSAGE_TYPING"],
          prefix: config.prefix,
        });

        boto.on('ready', () => {
          console.log(`Logged in as ${boto.user.tag}`);
        });
        const prefix = config.prefix;

        // Load the moderation configuration from file
        boto.on('messageCreate', (message) => {
          if (message.content.startsWith(prefix + `setadminrole`)) {
            // Check if the user has permission to manage server roles
            if (!message.member.permissions.has('MANAGE_ROLES')) {
              message.reply('You do not have permission to set the admin role.');
              return;
            }
            // Get the role name from the command argument
            const roleName = message.content.slice(14).trim();
            // Find the role object by name
            const role = message.guild.roles.cache.find(role => role.name === roleName);
            // If the role is found, update the server's configuration file
            if (role) {
              const configPath = `./mod_${message.guild.id}.json`;
              let config = {};
              try {
                config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
              } catch (err) {
                console.error(err);
              }
              config.adminRole = roleName;
              fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf8');
              message.reply(`The admin role has been set to ${roleName}.`);
            } else {
              message.reply('The role could not be found.');
            }
          }
        });


        boto.on('messageCreate', (message) => {
          if (message.content.startsWith(prefix + `resetconfig`)) {
            // Check if the user has permission to manage server roles
            if (!message.member.permissions.has('MANAGE_ROLES')) {
              message.reply('You do not have permission to reset the config.');
              return;
            }
            // Delete the server's configuration file
            const configPath = `./mod_${message.guild.id}.json`;
            try {
              fs.unlinkSync(configPath);
              message.reply('The configuration has been reset.');
            } catch (err) {
              // If the file doesn't exist, send an error message
              if (err.code === 'ENOENT') {
                message.reply(`There is no configuration data to reset.`);
              } else {
                console.error(err);
                message.reply(`An error occurred while resetting the configuration.`);
              }
            }
          }
        });

        /// 

        boto.on('messageCreate', (message) => {
          if (message.content.startsWith(prefix + `unban`)) {
            // Check if the user has the admin role
            const config = require('./mod.json');
            const adminRoleName = config.adminRole;
            const adminRole = message.guild.roles.cache.find(role => role.name === adminRoleName);
            if (!message.member.roles.cache.has(adminRole.id)) {
              message.reply('You do not have permission to use this command.');
              return;
            }
            // Proceed with the unban command as before
            const user = message.mentions.users.first();
            if (!user) {
              message.reply('Please mention a valid user ID');
              return;
            }
            message.guild.bans.fetch(user)
              .then(ban => {
                const member = ban.user;
                message.guild.members.unban(user.id)
                  .then(() => message.reply(`${user.tag} was unbanned from the server.`))
                  .catch(error => message.reply('Sorry, an error occurred.'));
              })
              .catch(error => message.reply('Sorry, an error occurred.'));
          }
        });

        ///
        boto.on('messageCreate', (message) => {
          if (message.content.startsWith(prefix + `ban`)) {
            // Check if the user has the admin role
            const config = require('./mod.json');
            const adminRoleName = config.adminRole;
            const adminRole = message.guild.roles.cache.find(role => role.name === adminRoleName);
            if (!message.member.roles.cache.has(adminRole.id)) {
              message.reply('You do not have permission to use this command.');
              return;
            }
            // Proceed with the ban command as before
            const member = message.mentions.members.first();
            if (!member) {
              message.reply('Please mention a valid member of this server');
              return;
            }
            member.ban()
              .then(() => message.reply(`${member.user.tag} was banned from the server.`))
              .catch(error => message.reply('Sorry, an error occurred.'));
          }
        });
//

boto.on('messageCreate', async (message) => {
  if (message.content.startsWith(prefix + `warn`)) {
    // Check if the user has the admin role
    const config = require('./mod.json');
    const adminRoleName = config.adminRole;
    const adminRole = message.guild.roles.cache.find(role => role.name === adminRoleName);
    if (!message.member.roles.cache.has(adminRole.id)) {
      message.reply('You do not have permission to use this command.');
      return;
    }
    // Get the warned member and reason from the command arguments
    const args = message.content.slice(6).trim().split(/ +/);
    const member = message.mentions.members.first();
    const reason = args.slice(1).join(' ');
    // Warn the member
    if (member) {
      const warnEmbed = new Discord.MessageEmbed()
        .setTitle(`Warning for ${member.user.tag}`)
        .setColor('#ff0000')
        .setDescription(`Reason: ${reason}`)
        .setTimestamp();
      message.channel.send({ embeds: [warnEmbed] });
      await member.send({embeds : [warnEmbed]})
    }
    }
  })

  ///
  boto.on('messageCreate', (message) => {
    if (message.content.startsWith(prefix + `kick`)) {
      // Check if the user has the admin role
      const config = require('./mod.json');
      const adminRoleName = config.adminRole;
      const adminRole = message.guild.roles.cache.find(role => role.name === adminRoleName);
      if (!message.member.roles.cache.has(adminRole.id)) {
        message.reply('You do not have permission to use this command.');
        return;
      }
      // Get the kicked member and reason from the command arguments
      const args = message.content.slice(6).trim().split(/ +/);
      const member = message.mentions.members.first();
      const reason = args.slice(1).join(' ');
      // Kick the member
      if (member) {
        member.kick(reason)
          .then(() => {
            const kickEmbed = new Discord.MessageEmbed()
              .setTitle(`User ${member.user.tag} has been kicked`)
              .setColor('#ff0000')
              .setDescription(`Reason: ${reason}`)
              .setTimestamp();
            message.channel.send({ embeds: [kickEmbed] });
          })
        }
      }
    })
        //

    
          ///

          boto.on('messageCreate', (message) => {
            if (message.content.startsWith(prefix + `mute`)) {
              // Check if the user has the admin role
              const config = require('./mod.json');
              const adminRoleName = config.adminRole;
              const adminRole = message.guild.roles.cache.find(role => role.name === adminRoleName);
              if (!message.member.roles.cache.has(adminRole.id)) {
                message.reply('You do not have permission to use this command.');
                return;
              }
              // Get the muted member and reason from the command arguments
              const args = message.content.slice(6).trim().split(/ +/);
              const member = message.mentions.members.first();
              const reason = args.slice(1).join(' ');
              // Mute the member
              if (member) {
                const muteRole = message.guild.roles.cache.find(role => role.name === 'Muted');
                if (!muteRole) {
                  message.reply('The Muted role does not exist. Please create it before using this command.');
                  return;
                }
                member.roles.add(muteRole, reason)
                  .then(() => {
                    const muteEmbed = new Discord.MessageEmbed()
                      .setTitle(`User ${member.user.tag} has been muted`)
                      .setColor('#ff0000')
                      .setDescription(`Reason: ${reason}`)
                      .setTimestamp();
                    message.channel.send({ embeds: [muteEmbed] });
                  })
                }
              }
            })

            boto.on('messageCreate', (message) => {
              if (message.content.startsWith(prefix + `unmute`)) {
                // Check if the user has the admin role
                const config = require('./mod.json');
                const adminRoleName = config.adminRole;
                const adminRole = message.guild.roles.cache.find(role => role.name === adminRoleName);
                if (!message.member.roles.cache.has(adminRole.id)) {
                  message.reply('You do not have permission to use this command.');
                  return;
                }
                // Get the unmuted member from the command arguments
                const member = message.mentions.members.first();
                if (member) {
                  const muteRole = message.guild.roles.cache.find(role => role.name === 'Muted');
                  if (!muteRole) {
                    message.reply('The Muted role does not exist. Please create it before using this command.');
                    return;
                  }
                  member.roles.remove(muteRole)
                    .then(() => {
                      const unmuteEmbed = new Discord.MessageEmbed()
                        .setTitle(`User ${member.user.tag} has been unmuted`)
                        .setColor('#00ff00')
                        .setTimestamp();
                      message.channel.send({ embeds: [unmuteEmbed] });
                    })
                  }
                }
              })


              
              ///

              boto.on('messageCreate', async message => {
                if (message.content.startsWith(prefix + `help`)) {
                  const help = new MessageEmbed()
                  .addFields(
                    {
                      name : `${prefix}setadminrole` ,
                      value : `**To set adminrole that can use the moderation commands {by the name of role}**`
                    }
                  )
                  .addFields(
                    {
                      name : `${prefix}ban` ,
                      value : `**To ban member {by} his id**`
                    }
                  )
                  .addFields(
                    {
                      name : `${prefix}unban` ,
                      value : `**To unban member**`
                    }
                  )
                  .addFields(
                    {
                      name : `${prefix}kick` ,
                      value : `**To kick member**`
                    }
                  )
                  .addFields(
                    {
                      name : `${prefix}warn` ,
                      value : `**To warn member**`
                    }
                  )
                  .addFields(
                    {
                      name : `${prefix}mute` ,
                      value : `**To mute member**`
                    }
                  )
                  .addFields(
                    {
                      name : `${prefix}unmute` ,
                      value : `**To unmute member**`
                    }
                  )
                  .addFields(
                    {
                      name : `${prefix}resetconfig` ,
                      value : `**To reset the role admin**`
                    }
                  )
                  .setImage('https://www.babup.com/do.php?img=25469')

                  await message.channel.send({embeds : [help]})
                
                }
              })
            

        boto.login(config.token);
      });
    }

  });
})

client.on('ready', () => {
  console.log('Logged in as', client.user.tag);
  gav.find({}, (err, docs) => {
    if (err) {
      console.error(err);
    } else {
      docs.forEach(config => {
        const botp = new Client({
          intents:  ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS" , "GUILD_PRESENCES" , "GUILD_BANS" , "GUILD_INVITES" , "GUILD_MESSAGE_REACTIONS" , "GUILD_MESSAGE_TYPING" , "DIRECT_MESSAGES" , "DIRECT_MESSAGE_REACTIONS" , "DIRECT_MESSAGE_TYPING"],
          prefix: config.prefix,
        });

        botp.on('ready', () => {
          console.log(`Logged in as ${botp.user.tag}`);
        });
        const prefix = config.prefix;
     
        botp.on('messageCreate', async message => {
          if (!message.content.startsWith(prefix) || message.author.bot) return;
        
          const args = message.content.slice(prefix.length).trim().split(/ +/);
          const command = args.shift().toLowerCase();
        
          if (command === 'ticket') {
            if (!message.member.permissions.has('ADMINISTRATION')) {
              message.reply('You do not have permission to use this command.');
              return;
            }

            const ticketButton = new MessageButton()
              .setCustomId('newTicketButton')
              .setLabel('Open Ticket')
              .setStyle('PRIMARY')
            .setEmoji('🎫')
              
        
            const actionRow = new MessageActionRow().addComponents(ticketButton);
        
            const embed = new MessageEmbed()
              .setColor('#0099ff')
              .setTitle('Do you need Help?')
              .setDescription('Click the button below to open a new support ticket.')
              .setImage('https://www.babup.com/do.php?img=25476')
        
            message.channel.send({ embeds: [embed], components: [actionRow] });
          }
        });
const rat = require('./models/category.js')
botp.on('messageCreate', async message => {
  if (!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'setticketcategory') {
    if (!message.member.permissions.has('ADMINISTRATOR')) return message.reply('You do not have permission to use this command.');
    if (!args[0]) return message.reply('You must provide a valid category ID.');

rat.findOne({id : message.guild.id} , async (data) => {
    if(!data) {
        rat.create(
        {
            id : message.guild.id , 
            category : args[0]
        })
    }
})
    // update or insert ticket category data for user
  await message.channel.send({content : `**Done saved category id **`})

    // write updated data to JSON file
    
  }
});
const count = require('./models/count.js')
let map = new Map()
let counter = 0 
counter++
          map.set(counter)  
          
       botp.on('interactionCreate', async interaction => {
  if (interaction.isButton()) {
    if (interaction.customId === 'newTicketButton') {
  const gata = await count.findOneAndUpdate({ id: interaction.guild.id }, { number: counter }, { upsert: true })
        
      const channelName = `ticket-${interaction.user.tag}`;
     
        const yew = await rat.findOne({id  : interaction.guild.id})
  const ticketCategory = interaction.guild.channels.cache.get(yew.category);

      // create a new ticket channel in the ticket category
      const channel = await ticketCategory.guild.channels.create(channelName, {
        type: 'GUILD_TEXT',
        permissionOverwrites: [
          {
            id: ticketCategory.guild.id,
            deny: [Permissions.FLAGS.VIEW_CHANNEL],
          },
          {
            id: interaction.user.id,
            allow: [Permissions.FLAGS.VIEW_CHANNEL],
          },
        ],
        parent: ticketCategory, // set the ticket category as the parent
      });
        

      // send a message to the new ticket channel
      const closeButton = new MessageButton()
        .setCustomId('closeTicketButton')
        .setLabel('Close Ticket')
        .setStyle('DANGER');

      const claimButton = new MessageButton()
        .setCustomId('claimTicketButton')
        .setLabel('Claim Ticket')
        .setStyle('PRIMARY');

      const actionRow = new MessageActionRow().addComponents(closeButton, claimButton);

      const embed = new MessageEmbed()
        .setColor('#0099ff')
        .setTitle('New Ticket Opened')
        .setDescription(`Ticket opened by ${interaction.user}. Please wait for a moderator to assist you.`);

      channel.send({ content: `${interaction.user}`, embeds: [embed], components: [actionRow] });
      await interaction.deferReply({ ephemeral: true });
      await interaction.editReply({ content: `**Ticket opened in ${channel}.**`, components: [] });
    }
  }
});

        botp.on('interactionCreate' , async interaction => {
          if (interaction.isButton()) {
            if (interaction.customId === 'closeTicketButton') {

              await interaction.channel.delete({timeout : 5000})

            }
            }
          })
          botp.on('interactionCreate', async interaction => {
            if (!interaction.isButton()) return;
          
            if (interaction.customId === 'claimTicketButton') {
              await interaction.deferUpdate();
          
              const member = interaction.member;
              const ticketChannel = interaction.channel;
              const everyoneRole = ticketChannel.guild.roles.everyone;
          
              // Remove the claim button and disable it for the member who claimed the ticket
              const claimButton = ticketChannel.messages.cache.first().components[0].components.find(component => component.customId === 'claimTicketButton');
              claimButton.setDisabled(true);
              await interaction.message.edit({ components: [interaction.message.components[0]] });
          
              // Update channel permissions to allow only the claiming member to send messages
   
          
              // Send a confirmation message to the claiming member
              await member.send(`You have claimed the ticket ${ticketChannel}! You can now send messages in this channel.`);
            }
          });

        botp.on('messageCreate', async message => {
                if (message.content.startsWith(prefix + `help`)) {
                  const help = new MessageEmbed()
                  .addFields(
                    {
                      name : `${prefix}setticketcategory` ,
                      value : `**To set a ticket category** `
                    }
                  )
                  .addFields(
                    {
                      name : `${prefix}ticket` ,
                      value : `**To show the ticket embed for members to be able to open ticket**`
                    }
                  )
                  .setImage('https://www.babup.com/do.php?img=25472')
                 

                  await message.channel.send({embeds : [help]})
                
                }
              })
            
        // bot.on('messageCreate', (message) => {
        //   if (message.content.startsWith(prefix + `resetconfigsug`)) {
        //     // Load the configuration from line.json
        //     const config = JSON.parse(fs.readFileSync('./sug.json'));
        
        //     // Reset the channels and line properties
        //     config.suggestionsChannel = "";
         
        
        //     // Write the updated configuration back to line.json
        //     fs.writeFileSync('./sug.json', JSON.stringify(config, null, 2));
        
        //     message.reply('**تم ازالة جميع الرومات التى تم اضافتها.**');
        //   }
        // });


        //
      
        
        
        // Connect to the database
   
        

        botp.login(config.token);
      });
    }

  });
})

////// open and close channels
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'loll') {
    await interaction.message.edit({
      components: [
        new MessageActionRow().addComponents(
          new MessageButton()
            .setCustomId('lolll')
            .setLabel('تم الضغط على الزر')
            .setStyle('PRIMARY')
            .setDisabled(true),
          new MessageButton()
            .setCustomId('close')
            .setLabel('لقفل الروم')
            .setStyle('DANGER')
            .setDisabled(false)
        ),
      ],
    });
    const prece = require('./models/prece')
    const tt = await proce.findOne({ id: interaction.guild.id });
    const ttt = await Owner.findOne({ id: interaction.guild.id });


    const owner = ttt.owner
  

  
    // Fetch the member by ID
    
      // Fetch the member by ID
      await interaction.deferReply({ ephemeral: true });
      await interaction.editReply({ content: `**Done clicked**` });
      await interaction.channel.send({
        embeds: [
          new MessageEmbed().setDescription(`**
          .قم بكتابه امر التحويل التالي
          c ${owner} ${tt.Price.open}
          لديك 5 دقايق حتي تقوم بتحويل المبلغ
        **`),
        ],
      });
      await interaction.channel.send({ content: `c ${owner} ${tt.Price.open}` });
    } 
  
});





client.on('messageCreate', async message => {
  if (message.author.bot) return;
  const rr = await prece.findOne({id : message.guild.id})
  const ttt = await Owner.findOne({ id: message.guild.id });


  const owner = ttt.owner

  let price_without = `${rr.Price.open}` // boost tool
  let ownerId = `${owner}`
  const probotId = '282859044593598464'
  const role = message.guild.roles.cache.get('1123483457360773190')
  let trans_msg = `**:moneybag: | ${message.author.username}, has transferred \`$${price_without}\` to <@!${ownerId}> **`;
  let collect2 = await message.channel.awaitMessages({
    filter: mm => mm.author.id === probotId && mm.content === trans_msg,
    max: 1,
    time: 0
  }).catch(() => 0);
  collect2 = collect2.first();
  if (!collect2) return;
  if (collect2.content != trans_msg) return;

  const lastTimestamp = buttonTimestamps.get(message.author.id) || 0;
  const now = Date.now();

  if (now - lastTimestamp >= buttonCooldown) {
    const button = new MessageButton()
      .setCustomId('kii')
      .setLabel('click')
      .setStyle('DANGER');

    const row = new MessageActionRow()
      .addComponents(button);

    message.channel.send({ content : `**اضغط على الزر وقم باضافة التوكن والبريفكس فى المكان المحدد لهما**` ,
      components: [row]
    });

    buttonTimestamps.set(message.author.id, now);
  }
});


////// online close and open bot 




client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return
  if (interaction.customId === 'kii') {
    const modall = new Modal()
      .setCustomId('myModall')
      .setTitle('My Modal');
    const tokenn = new TextInputComponent()
      .setCustomId('tokenn')
      // The label is the prompt the user sees for this input
      .setLabel("bot tokenn")
      // Short means only a single line of text
      .setStyle('SHORT');
    const prefixx = new TextInputComponent()
      .setCustomId('prefixx')
      .setLabel("bot prefixx")
      // Paragraph means multiple lines of text.
      .setStyle('SHORT');
    // An action row only holds one text input,
    // so you need one action row per text input.
    const firstActionRoww = new MessageActionRow().addComponents(tokenn);
    const secondActionRoww = new MessageActionRow().addComponents(prefixx);
    // Add inputs to the modal
    modall.addComponents(firstActionRoww, secondActionRoww);
    // Show the modal to the user
    await interaction.showModal(modall);
  }
})

client.on('interactionCreate', async interactionn => {
  if (!interactionn.isModalSubmit()) return;

  if(interactionn.customId === 'myModall') {
  // Get the data entered by the user
  const tokenn = interactionn.fields.getTextInputValue('tokenn');
  const prefixx = interactionn.fields.getTextInputValue('prefixx');

  oc.findOne({
    id: interactionn.guild.id
  }, async (data) => {
    if (!data) {
      oc.create({
        id: interactionn.guild.id,
        token: tokenn,
        prefix: prefixx
      })


    }
  })

  console.log(tokenn, prefixx)

  const ha = await oc.findOne({
    id: interactionn.guild.id
  })


  // const bot = new Client({
  //   intents: ['GUILD_MESSAGES', 'GUILDS'],
  //   prefix: prefix,
  // });

  // bot.on('ready', () => {
  //   console.log(`Logged in as ${bot.user.tag}`);
  // });
  


  // const tax = require('probot-taxs');
  // bot.on('messageCreate', async message => {
  //   if (message.content.startsWith('tax')) {
  //     const args = message.content.split(' ').slice('1').join(' ')
  //     let taxs = tax.tax(args, true)
  //     let taxbader = new MessageEmbed()
  //       .setTitle('the tax of probot')
  //       .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
  //       .addFields({ name: 'the tax of probot', value: `**${taxs.tax}**` })
  //       .addFields({ name: 'the tax with wasit', value: `**${taxs.wasit}**` })
  //       .setTimestamp();

  //     await message.reply({ embeds: [taxbader] });
  //   }
  // });

  // bot.login(token);


  const tt = await logg.findOne({ id: interactionn.guild.id });
  const channelMention = tt.channel;
  const channelId = channelMention.match(/\d+/)[0];
  const channel = await interactionn.guild.channels.cache.get(channelId);
  const ttt = await loggg.findOne({id : interactionn.guild.id})
  const channell = await interactionn.guild.channels.cache.get(ttt.channel);
  const userr = interactionn.user.username;
  await channell.send({content : `**Open and Close channels bot has been bought by ${userr}**`})
  await channel.send({
    content: `**Done purchased Open and Close channels ${tokenn} \n prefix :- ${prefixx} \n Id : ${myId} \n Purshased by : ${interactionn.user}**`,
  });
  const user = interactionn.user
  user.send({ content: `Done purchased ${tokenn} \n prefix :- ${prefixx} ` })
  await interactionn.update({
    content: `**Done purchased ${tokenn} \n prefix :- ${prefixx}** `,
    components : [new MessageActionRow().addComponents (
      new MessageButton()
      .setCustomId('kii')
      .setLabel('تم الضغط')
      .setStyle('DANGER')
      .setDisabled(true)
    )]
  });

  }



});



client.login(token).catch((err) => {
  console.error(`Error logging in with token ${token}: ${err}`);
});

return client;
}

module.exports = createKickBot;
      
   