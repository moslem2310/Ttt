const { Schema, model } = require("mongoose");

const prefix = new Schema (
  {
    id: {
      type: String,
      required: true,
    },
    prefix: {
      type: String,
      required: true,
    },

  }
)
module.exports = model ('prefix' , prefix)