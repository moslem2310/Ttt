const { Schema, model } = require("mongoose");
const prece = new  Schema({
  id: { type: String},
Price : 
    {
        tax : {type : Number} ,
        open : {type : Number} ,
        autoline : {type : Number} ,
        broadcast : {type : Number} ,
        suggestion : {type : Number} ,
        moderation : {type : Number} ,
        ticket : {type : Number} ,
        giveaway : {type : Number} ,
        say : {type : Number} ,
        come : {type : Number},
       


    
},
owner : {type : String},

});

module.exports = model("prece",prece)
