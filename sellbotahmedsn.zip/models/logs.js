const { Schema, model } = require("mongoose");

const log = new Schema (
  {
    id: {
      type: String,
      required: true,
    },
    channel: {
      type: String,
      required: true,
    },

  }
)
module.exports = model ('log' , log)