const {model , Schema} = require ('mongoose')

const emo = new Schema (
    {
        id : String , 
        image : String , 
    }

)

module.exports = model('emo' , emo)