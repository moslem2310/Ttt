const { Schema, model } = require("mongoose");
const counter = new  Schema({
  id: { type: String},
  count : {type : Number}
 

});

module.exports = model("counter",counter)