const { model , Schema } = require ('mongoose');

const autoLineSchema = new Schema ({
    channelID: {
        type: String,
        unique: true,
    }
});

module.exports = model ('AutoLine', autoLineSchema);