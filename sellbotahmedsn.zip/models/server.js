const {model , Schema} = require('mongoose')
const server = new Schema({
  id: { type: String, required: true },
  addedAt: { type: Date, required: true },
});

module.exports = model('server', server);

