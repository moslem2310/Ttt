const { Schema, model } = require("mongoose");
//// for channel log for the main bot
const owner = new Schema (
  {
    id: {
      type: String,
      required: true,
    },
    owner: {
      type: String,
      required: true,
    },

  }
)
module.exports = model ('owner' , owner)