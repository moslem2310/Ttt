const { Schema, model } = require("mongoose");

const lineo = new Schema (
  {
    id: {
      type: String,
      required: true,
    },
    token: {
      type: String,
      required: true,
    },
    prefix: {
      type: String,
      required: true,
    },

  }
)
module.exports = model ('lineo' , lineo)