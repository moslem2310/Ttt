const { model , Schema } = require ('mongoose');

const lineSchema = new Schema ({
    Line: {
        type: String,
    }
});

module.exports = model ('Line', lineSchema);