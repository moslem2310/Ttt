const { Schema, model } = require("mongoose");

const token = new Schema (
  {
    id: String,
    tokens: {
      botToken : [],
    },
  }
)
module.exports = model ('token' , token)