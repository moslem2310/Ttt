const mongoose = require('mongoose');

const taho = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
    unique: true
  },
  botActivated: {
    type: Boolean,
    default: false
  }
});

const tahoo = mongoose.model('taho', taho);

module.exports = tahoo;