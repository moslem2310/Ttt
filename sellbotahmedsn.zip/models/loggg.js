const { Schema, model } = require("mongoose");
//// for channel log for the main bot
const loggg = new Schema (
  {
    id: {
      type: String,
      required: true,
    },
    channel: {
      type: String,
      required: true,
    },

  }
)
module.exports = model ('loggg' , loggg)