const { model , Schema } = require ('mongoose');

const suggestSchema = new Schema ({
    channelID: {
        type: String,
        unique: true,
    }
});

module.exports = model ('Suggest', suggestSchema);