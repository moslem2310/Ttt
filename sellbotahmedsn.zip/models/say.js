const { Schema, model } = require("mongoose");

const say = new Schema (
  {
    id: {
      type: String,
      required: true,
    },
    token: {
      type: String,
      required: true,
    },
    prefix: {
      type: String,
      required: true,
    },

  }
)
module.exports = model ('say' , say)