const { Schema, model } = require("mongoose");
//// for channel log for the main bot
const logg = new Schema (
  {
    id: {
      type: String,
      required: true,
    },
    channel: {
      type: String,
      required: true,
    },

  }
)
module.exports = model ('logg' , logg)