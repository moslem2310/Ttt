////// https://youtu.be/gtykpkOYy94
require("dotenv").config();
const config = require("./config.json");
const prefix = config.prefix;
const Discord = require("discord.js");
const fs = require('fs');
const { MessageAttachment } = require('discord.js');
const { MessageEmbed, MessageButton , MessageActionRow ,  permissionOverwrites, ChannelType, Permissions } = require("discord.js");
const { Client, Intents } = require('discord.js');
const client = new Discord.Client({
  intents: ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS"]
});


// Require the ban bot module and pass the Client class
// const banBot = require('./banBot')(Client, ''); ////////// https://youtu.be/gtykpkOYy94

client.once('ready', () => {
  console.log('Bot is online!');
});
const mongoose = require("mongoose");
const db = require("./models/shop");
const user_db = require("./models/user");
const toto = require("./models/steck");
const tokens = require("./models/tokens");
const setSlash = require("./slash");
const axios = require("axios");
const i18n = require('i18n');

i18n.configure({
  locales: ['en', 'ar'],
  directory: __dirname + '/locales',
  defaultLocale: 'en',
  objectNotation: true
});


mongoose.connect("mongodb+srv://Ahmed:12345@ahmed.f1uxuex.mongodb.net/data");


    console.log('Connected to MongoDB');
client.on("ready", async () => {
  console.log(client.user.tag);
  await setSlash(client);
});

process.on("unhandledRejection", error => {
  return;
});
process.on("unhandledRejection", error => {
  return;
});
process.on("unhandledRejection", error => {
  return;
});

process.on("unhandledRejection", error => {
  return console.log(error)
});




client.on('ready', () => {
  function abady() {
    let status = [`Ahmed Sn`]
    let S = Math.floor(Math.random() * status.length);
    client.user.setActivity(status[S], { type: 'PLAYING' })
  };
  //ismailmgde
  setInterval(abady, 5000)

})


///////////////////////////// https://youtu.be/gtykpkOYy94   
///
const token = require('./models/tokenn.js');
const createKickBot = require('./kickBot');
const banBot = require('./banBot');
const user = require('./models/userr.js')

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isCommand()) return;

  if (interaction.commandName === 'activate-bot') {
    // Check if the user has already used the command
   

    const botToken = interaction.options.getString('bot-token');
    const btre = new MessageButton()
      .setCustomId('btro')
      .setLabel('ترجمة الى اللغة العربية')
      .setStyle('PRIMARY')
      .setEmoji('1128389047862177932')

    const gar = new MessageActionRow()
      .addComponents(btre)
    if (botToken) {
      await interaction.deferReply({ ephemeral: true });
      await interaction.editReply({
        content: `**Ok the Subscription is Done successfully ✅ you can try now slash commands for your bot**`, components: [gar]
      });
    }


    const existingToken = await token.findOne({ guildId: interaction.guild.id });
    if (!existingToken) {
      // Create a new document if one does not exist for the guild
      const newToken = new token({
        guildId: interaction.guild.id,
        botTokens: [botToken],
      });

      await newToken.save();
    } else {
      // Update the botTokens array if a document already exists
      existingToken.botTokens.push(botToken);
      await existingToken.save();
    }

    let activatedBot = createKickBot(botToken);
    await activatedBot.connect();

    // Set the botActivated flag to true for the user in the database

  }
});



/// https://youtu.be/gtykpkOYy94

client.login("MTEyODQ0MjQxNjYzOTI2NjgxNw.GCCyl8.ypz1UmBJtleVpN2_RRVZlM844Or9uQoZfGg2n4");