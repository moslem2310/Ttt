const token = require('./models/tokens');
const kickBot = require('./kickBot');

async function handleInteractionCreate(interaction) {
  if (!interaction.isCommand()) return;

  if (interaction.commandName === 'activate-bot') {
    const botToken = interaction.options.getString('bot-token');

    token.findOne({ id: interaction.guild.id }, async (err, data) => {
      if (err) throw err;

      if (!data) {
        // Create a new document if one does not exist for the guild
        const newToken = new token({
          id: interaction.guild.id,
          tokens: {
            botToken: [botToken],
          },
        });

        await newToken.save();
      } else {
        // Update the tokens array if a document already exists
        data.tokens.botToken.push(botToken);
        await data.updateOne({ tokens: data.tokens });
      }
    });

    let activatedBot = new kickBot(botToken);
    await activatedBot.connect();
    
    if (botToken) {
      await interaction.deferReply({ ephemeral: true });
      await interaction.editReply({
        content: `**Ok the Subscription is Done successfully ✅ you can try now slash commands for your bot**`
      });
    }
  }
}

module.exports = {
  handleInteractionCreate
};