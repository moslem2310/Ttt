
module.exports = async (bot) => {
  let array = [
    

    {
      name: "say",
      description: "say anything",
      options: [

            {
              name: "with-embed",
              description: "say with embed",
              type: "STRING" ,
              required : false
            } ,
            {
              name: "without-embed",
              description: "say without embed",
              type: "STRING" ,
              required : false
            },
   


          ]
        },

                  
]
  await bot.application.commands.set(array);
}