
module.exports = async (client) => {
  let array = [
    
                    
                    {
                      name: 'activate-bot',
                      description: 'Activate a bot with the specified token',
                      options: [
                     
                        {
                          name: 'bot-token',
                          description: 'The token for the bot',
                          type: 'STRING',
                          required: true
                        }
                      ]
                     
                  },
                ]
              

                    
                       

                 
        
             
                  


 
  
  await client.application.commands.set(array);
}
